-- Create schema for WrenchLoop

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  is_commercial BOOLEAN DEFAULT FALSE,
  company_name TEXT,
  default_public BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  subscription_tier TEXT DEFAULT 'free' CHECK (subscription_tier IN ('free', 'small', 'large')),
  stripe_customer_id TEXT,
  subscription_id TEXT
);

-- Assets table
CREATE TABLE IF NOT EXISTS assets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER NOT NULL,
  engine TEXT NOT NULL,
  transmission TEXT NOT NULL,
  notes TEXT,
  vin_serial TEXT
);

-- Repair logs table
CREATE TABLE IF NOT EXISTS repair_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  asset_id UUID REFERENCES assets(id) ON DELETE SET NULL,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER NOT NULL,
  engine TEXT NOT NULL,
  transmission TEXT NOT NULL,
  issue_description TEXT NOT NULL,
  cause TEXT NOT NULL,
  repair_notes TEXT,
  tools_used TEXT,
  miles_hours NUMERIC,
  total_cost NUMERIC,
  is_public BOOLEAN DEFAULT TRUE,
  thumbs_up INTEGER DEFAULT 0,
  thumbs_down INTEGER DEFAULT 0,
  is_hidden BOOLEAN DEFAULT FALSE
);

-- Maintenance logs table
CREATE TABLE IF NOT EXISTS maintenance_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  asset_id UUID REFERENCES assets(id) ON DELETE CASCADE NOT NULL,
  maintenance_type TEXT NOT NULL,
  description TEXT,
  miles_hours NUMERIC NOT NULL,
  total_cost NUMERIC
);

-- Parts table
CREATE TABLE IF NOT EXISTS parts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  log_id UUID NOT NULL,
  log_type TEXT NOT NULL CHECK (log_type IN ('repair', 'maintenance')),
  part_number TEXT,
  name TEXT NOT NULL,
  price NUMERIC
);

-- Photos table
CREATE TABLE IF NOT EXISTS photos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  log_id UUID NOT NULL,
  log_type TEXT NOT NULL CHECK (log_type IN ('repair', 'maintenance')),
  url TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Votes table
CREATE TABLE IF NOT EXISTS votes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  repair_id UUID REFERENCES repair_logs(id) ON DELETE CASCADE NOT NULL,
  vote_type TEXT NOT NULL CHECK (vote_type IN ('up', 'down')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, repair_id)
);

-- Bookmarks table
CREATE TABLE IF NOT EXISTS bookmarks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  repair_id UUID REFERENCES repair_logs(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, repair_id)
);

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  repair_id UUID REFERENCES repair_logs(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create RLS policies
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE repair_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE parts ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Assets policies
CREATE POLICY "Users can view their own assets"
  ON assets FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own assets"
  ON assets FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own assets"
  ON assets FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own assets"
  ON assets FOR DELETE
  USING (auth.uid() = user_id);

-- Repair logs policies
CREATE POLICY "Users can view their own repair logs"
  ON repair_logs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view public repair logs"
  ON repair_logs FOR SELECT
  USING (is_public = true AND is_hidden = false);

CREATE POLICY "Users can create their own repair logs"
  ON repair_logs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own repair logs"
  ON repair_logs FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own repair logs"
  ON repair_logs FOR DELETE
  USING (auth.uid() = user_id);

-- Maintenance logs policies
CREATE POLICY "Users can view their own maintenance logs"
  ON maintenance_logs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own maintenance logs"
  ON maintenance_logs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own maintenance logs"
  ON maintenance_logs FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own maintenance logs"
  ON maintenance_logs FOR DELETE
  USING (auth.uid() = user_id);

-- Parts policies
CREATE POLICY "Anyone can view parts for public repair logs"
  ON parts FOR SELECT
  USING (
    (log_type = 'repair' AND 
     EXISTS (SELECT 1 FROM repair_logs WHERE repair_logs.id = parts.log_id AND repair_logs.is_public = true AND repair_logs.is_hidden = false))
    OR
    (log_type = 'maintenance' AND 
     EXISTS (SELECT 1 FROM maintenance_logs WHERE maintenance_logs.id = parts.log_id AND 
             EXISTS (SELECT 1 FROM profiles WHERE profiles.id = maintenance_logs.user_id AND profiles.id = auth.uid())))
  );

CREATE POLICY "Users can view parts for their own logs"
  ON parts FOR SELECT
  USING (
    (log_type = 'repair' AND 
     EXISTS (SELECT 1 FROM repair_logs WHERE repair_logs.id = parts.log_id AND repair_logs.user_id = auth.uid()))
    OR
    (log_type = 'maintenance' AND 
     EXISTS (SELECT 1 FROM maintenance_logs WHERE maintenance_logs.id = parts.log_id AND maintenance_logs.user_id = auth.uid()))
  );

CREATE POLICY "Users can create parts for their own logs"
  ON parts FOR INSERT
  WITH CHECK (
    (log_type = 'repair' AND 
     EXISTS (SELECT 1 FROM repair_logs WHERE repair_logs.id = parts.log_id AND repair_logs.user_id = auth.uid()))
    OR
    (log_type = 'maintenance' AND 
     EXISTS (SELECT 1 FROM maintenance_logs WHERE maintenance_logs.id = parts.log_id AND maintenance_logs.user_id = auth.uid()))
  );

CREATE POLICY "Users can update parts for their own logs"
  ON parts FOR UPDATE
  USING (
    (log_type = 'repair' AND 
     EXISTS (SELECT 1 FROM repair_logs WHERE repair_logs.id = parts.log_id AND repair_logs.user_id = auth.uid()))
    OR
    (log_type = 'maintenance' AND 
     EXISTS (SELECT 1 FROM maintenance_logs WHERE maintenance_logs.id = parts.log_id AND maintenance_logs.user_id = auth.uid()))
  );

CREATE POLICY "Users can delete parts for their own logs"
  ON parts FOR DELETE
  USING (
    (log_type = 'repair' AND 
     EXISTS (SELECT 1 FROM repair_logs WHERE repair_logs.id = parts.log_id AND repair_logs.user_id = auth.uid()))
    OR
    (log_type = 'maintenance' AND 
     EXISTS (SELECT 1 FROM maintenance_logs WHERE maintenance_logs.id = parts.log_id AND maintenance_logs.user_id = auth.uid()))
  );

-- Photos policies (similar to parts)
CREATE POLICY "Anyone can view photos for public repair logs"
  ON photos FOR SELECT
  USING (
    (log_type = 'repair' AND 
     EXISTS (SELECT 1 FROM repair_logs WHERE repair_logs.id = photos.log_id AND repair_logs.is_public = true AND repair_logs.is_hidden = false))
    OR
    (log_type = 'maintenance' AND 
     EXISTS (SELECT 1 FROM maintenance_logs WHERE maintenance_logs.id = photos.log_id AND 
             EXISTS (SELECT 1 FROM profiles WHERE profiles.id = maintenance_logs.user_id AND profiles.id = auth.uid())))
  );

CREATE POLICY "Users can view photos for their own logs"
  ON photos FOR SELECT
  USING (
    (log_type = 'repair' AND 
     EXISTS (SELECT 1 FROM repair_logs WHERE repair_logs.id = photos.log_id AND repair_logs.user_id = auth.uid()))
    OR
    (log_type = 'maintenance' AND 
     EXISTS (SELECT 1 FROM maintenance_logs WHERE maintenance_logs.id = photos.log_id AND maintenance_logs.user_id = auth.uid()))
  );

CREATE POLICY "Users can create photos for their own logs"
  ON photos FOR INSERT
  WITH CHECK (
    (log_type = 'repair' AND 
     EXISTS (SELECT 1 FROM repair_logs WHERE repair_logs.id = photos.log_id AND repair_logs.user_id = auth.uid()))
    OR
    (log_type = 'maintenance' AND 
     EXISTS (SELECT 1 FROM maintenance_logs WHERE maintenance_logs.id = photos.log_id AND maintenance_logs.user_id = auth.uid()))
  );

CREATE POLICY "Users can delete photos for their own logs"
  ON photos FOR DELETE
  USING (
    (log_type = 'repair' AND 
     EXISTS (SELECT 1 FROM repair_logs WHERE repair_logs.id = photos.log_id AND repair_logs.user_id = auth.uid()))
    OR
    (log_type = 'maintenance' AND 
     EXISTS (SELECT 1 FROM maintenance_logs WHERE maintenance_logs.id = photos.log_id AND maintenance_logs.user_id = auth.uid()))
  );

-- Votes policies
CREATE POLICY "Anyone can view votes"
  ON votes FOR SELECT
  USING (true);

CREATE POLICY "Users can create their own votes"
  ON votes FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own votes"
  ON votes FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own votes"
  ON votes FOR DELETE
  USING (auth.uid() = user_id);

-- Bookmarks policies
CREATE POLICY "Users can view their own bookmarks"
  ON bookmarks FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own bookmarks"
  ON bookmarks FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own bookmarks"
  ON bookmarks FOR DELETE
  USING (auth.uid() = user_id);

-- Comments policies
CREATE POLICY "Anyone can view comments on public repair logs"
  ON comments FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM repair_logs 
      WHERE repair_logs.id = comments.repair_id 
      AND repair_logs.is_public = true
      AND repair_logs.is_hidden = false
    )
  );

CREATE POLICY "Users can view comments on their own repair logs"
  ON comments FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM repair_logs 
      WHERE repair_logs.id = comments.repair_id 
      AND repair_logs.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create their own comments"
  ON comments FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own comments"
  ON comments FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own comments"
  ON comments FOR DELETE
  USING (auth.uid() = user_id);

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, is_commercial, default_public, subscription_tier)
  VALUES (new.id, new.email, false, true, 'free');
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create function to check asset limits
CREATE OR REPLACE FUNCTION check_asset_limit() 
RETURNS TRIGGER AS $$
DECLARE
  asset_count INTEGER;
  user_tier TEXT;
  max_assets INTEGER;
BEGIN
  -- Get user's subscription tier
  SELECT subscription_tier INTO user_tier
  FROM profiles
  WHERE id = NEW.user_id;
  
  -- Set max assets based on tier
  IF user_tier = 'free' THEN
    max_assets := 5;
  ELSIF user_tier = 'small' THEN
    max_assets := 20;
  ELSIF user_tier = 'large' THEN
    max_assets := 150;
  ELSE
    max_assets := 5; -- Default to free tier
  END IF;
  
  -- Count existing assets
  SELECT COUNT(*) INTO asset_count
  FROM assets
  WHERE user_id = NEW.user_id;
  
  -- Check if limit would be exceeded
  IF asset_count >= max_assets THEN
    RAISE EXCEPTION 'Asset limit reached for your subscription tier';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for asset limit check
CREATE TRIGGER check_asset_limit_trigger
  BEFORE INSERT ON assets
  FOR EACH ROW
  EXECUTE FUNCTION check_asset_limit();

-- Create function to auto-hide repair logs with bad votes
CREATE OR REPLACE FUNCTION check_repair_votes() 
RETURNS TRIGGER AS $$
DECLARE
  total_votes INTEGER;
BEGIN
  -- Only proceed if this is an update to thumbs_up or thumbs_down
  IF (TG_OP = 'UPDATE' AND (OLD.thumbs_up != NEW.thumbs_up OR OLD.thumbs_down != NEW.thumbs_down)) THEN
    total_votes := NEW.thumbs_up + NEW.thumbs_down;
    
    -- Check if we should auto-hide based on vote criteria
    IF total_votes >= 25 AND NEW.thumbs_down > (total_votes * 0.5) THEN
      NEW.is_hidden := TRUE;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for auto-hiding repair logs
CREATE TRIGGER check_repair_votes_trigger
  BEFORE UPDATE ON repair_logs
  FOR EACH ROW
  EXECUTE FUNCTION check_repair_votes();
