"use client"

import { useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import { RepairsContent } from "@/app/repairs/repairs-content"

export function RepairsContentWrapper() {
  const searchParams = useSearchParams()
  const query = searchParams.get("query") || ""
  const [search, setSearch] = useState(query)

  useEffect(() => {
    setSearch(query)
  }, [query])

  return <RepairsContent initialSearch={search} />
}
