import Image from "next/image"
import Link from "next/link"

export function Logo() {
  return (
    <Link href="/" className="flex items-center space-x-2">
      <Image
        src="/wrenchloopsloppyvector.svg?height=40&width=40"
        alt="WrenchLoop Logo"
        width={40}
        height={40}
        className="rounded-md"
      />
      <span className="font-bold text-xl text-blue-600">WrenchLoop</span>
    </Link>
  )
}
