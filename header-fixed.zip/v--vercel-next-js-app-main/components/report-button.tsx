"use client"

import { useState, useEffect } from "react"
import { useSupabase } from "@/lib/supabase-provider"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"

export function ReportButton({ postId }: { postId: string }) {
  const [open, setOpen] = useState(false)
  const [reason, setReason] = useState("")
  const [userId, setUserId] = useState<string | null>(null)
  const { supabase } = useSupabase()

  // Get the logged-in user's ID on mount
  useEffect(() => {
    const fetchUser = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      setUserId(user?.id ?? null)
    }
    fetchUser()
  }, [supabase])

  const handleSubmit = async () => {
    if (!userId) {
      toast.error("You must be signed in to report a post.")
      return
    }

    const { error } = await supabase.from("reports").insert({
      post_id: postId,
      user_id: userId,
      reason,
    })

    if (error) {
      toast.error("Failed to submit report.")
    } else {
      toast.success("Report submitted.")
      setReason("")
      setOpen(false)
    }
  }

  if (!userId) return null // Hide from unauthenticated users

  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)}>
        🚩 Report Post
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Report Post</DialogTitle>
            <DialogDescription>
              Describe how this post violates our guidelines.
            </DialogDescription>
          </DialogHeader>
          <Textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Reason for report..."
          />
          <Button onClick={handleSubmit} disabled={!reason.trim()}>
            Submit Report
          </Button>
        </DialogContent>
      </Dialog>
    </>
  )
}