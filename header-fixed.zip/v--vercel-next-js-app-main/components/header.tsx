"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Logo } from "@/components/logo"
import { useSupabase } from "@/lib/supabase-provider"
import { useState, useEffect } from "react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { User, LogOut, Settings, BarChart, Wrench, Car } from "lucide-react"

type HeaderProps = {
  transparent?: boolean
}

export function Header({ transparent = false }: HeaderProps) {
  const pathname = usePathname()
  const { supabase } = useSupabase()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    async function getUser() {
      const { data } = await supabase.auth.getUser()
      setUser(data.user)
      setLoading(false)
    }
    getUser()

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null)
      setLoading(false)
    })

    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [supabase])

  useEffect(() => {
    if (!transparent) return

    const onScroll = () => {
      setScrolled(window.scrollY > 20)
    }

    onScroll()
    window.addEventListener("scroll", onScroll)
    return () => window.removeEventListener("scroll", onScroll)
  }, [transparent])

  const isActive = (path: string) => pathname === path

  const bgStyle = transparent
    ? scrolled
      ? "fixed bg-white text-black shadow-md"
      : "absolute bg-transparent text-white"
    : "sticky bg-white text-black border-b"

  return (
    <header className={`top-0 z-50 w-full transition-all duration-300 ${bgStyle}`}>
      {/* Alert bar stays the same */}
      <div className="bg-yellow-100 border-b border-yellow-300 text-yellow-800 text-sm text-center py-2 px-4">
        🚧 Early Release – Help us improve by reporting issues.
        <button
          onClick={() =>
            window.open("mailto:support@wrenchloop.com?subject=Issue%20Report", "_blank")
          }
          className="ml-3 underline text-blue-600 hover:text-blue-800"
        >
          Report an Issue
        </button>
      </div>

      {/* Main nav bar */}
      <div className="w-full max-w-screen-xl mx-auto px-4 flex flex-wrap items-center justify-between gap-y-2 sm:flex-nowrap h-auto sm:h-16">
        <div className="flex items-center gap-6">
          <Logo />
          {user && !loading && (
            <nav className="hidden md:flex gap-6">
              {[
                ["/dashboard", "Dashboard"],
                ["/logs", "My Logs"],
                ["/repairs", "Community Repairs"],
                ["/analytics", "Analytics"],
              ].map(([href, label]) => (
                <Link
                  key={href}
                  href={href}
                  className={`text-sm font-medium transition-colors hover:text-blue-600 ${
                    isActive(href) ? "text-blue-600" : "text-gray-600"
                  }`}
                >
                  {label}
                </Link>
              ))}
            </nav>
          )}
          {!user && !loading && (
            <nav className="hidden md:flex gap-6">
              <Link
                href="/repairs"
                className={`text-sm font-medium transition-colors hover:text-blue-600 ${
                  isActive("/repairs") ? "text-blue-600" : "text-gray-600"
                }`}
              >
                Community Repairs
              </Link>
              <Link
                href="/pricing"
                className={`text-sm font-medium transition-colors hover:text-blue-600 ${
                  isActive("/pricing") ? "text-blue-600" : "text-gray-600"
                }`}
              >
                Pricing
              </Link>
            </nav>
          )}
        </div>

        {/* Auth buttons / profile menu */}
        <div className="flex items-center gap-4">
          {user && !loading ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex flex-col space-y-1 leading-none">
                    <p className="font-medium">{user.email}</p>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/dashboard" className="cursor-pointer w-full">
                    <Car className="mr-2 h-4 w-4" />
                    <span>Dashboard</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/logs" className="cursor-pointer w-full">
                    <Wrench className="mr-2 h-4 w-4" />
                    <span>My Logs</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/analytics" className="cursor-pointer w-full">
                    <BarChart className="mr-2 h-4 w-4" />
                    <span>Analytics</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings" className="cursor-pointer w-full">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer" onClick={() => supabase.auth.signOut()}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : !loading ? (
            <>
              <Link href="/login">
                <Button variant="ghost">Sign In</Button>
              </Link>
              <Link href="/signup">
                <Button>Sign Up for Free</Button>
              </Link>
            </>
          ) : null}
        </div>
      </div>
    </header>
  )
}
