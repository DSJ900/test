"use client"

import { useRouter } from "next/navigation"
import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function LandingPageClient() {
  const [term, setTerm] = useState("")
  const router = useRouter()

  const handleSearch = () => {
    if (!term.trim()) return
    router.push(`/repairs?query=${encodeURIComponent(term.trim())}`)
  }

  return (
    <>
      {/* Hero Section */}
      <section className="relative w-full min-h-[90vh] bg-black overflow-hidden text-white flex flex-col items-center justify-center px-6">
        {/* Background glow blobs */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          <div className="absolute top-1/3 left-1/4 w-[600px] h-[600px] bg-blue-800 opacity-[0.1] rounded-full blur-3xl animate-slow-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-blue-600 opacity-[0.12] rounded-full blur-2xl animate-slow-ping" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 text-center max-w-3xl space-y-6">
          <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight animate-fade-up">
            Welcome to <span className="text-blue-500">WrenchLoop</span>.
          </h1>
          <p className="text-gray-300 text-lg md:text-xl max-w-xl mx-auto animate-fade-up-delay">
            Track repairs. Share knowledge. Simplify maintenance. All in one sleek platform.
          </p>

          {/* Search bar */}
          <div className="flex items-center justify-center gap-2 mt-6 animate-fade-up-delay">
            <input
              type="text"
              value={term}
              onChange={(e) => setTerm(e.target.value)}
              placeholder="Search public logs..."
              className="bg-gray-900 border border-gray-700 rounded-full px-5 py-3 text-sm w-[280px] md:w-[400px] focus:outline-none focus:ring-2 focus:ring-blue-600 transition-all"
            />
            <button
              onClick={handleSearch}
              className="bg-blue-600 hover:bg-blue-700 transition-colors text-white px-4 py-3 rounded-full"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35M11 18a7 7 0 100-14 7 7 0 000 14z" />
              </svg>
            </button>
          </div>

          {/* CTA buttons */}
          <div className="flex justify-center gap-4 mt-8 animate-fade-up-delay">
            <Link href="/signup">
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full text-sm font-medium transition">
                Sign up
              </button>
            </Link>
            <Link href="/pricing">
              <button className="border border-white text-white px-6 py-3 rounded-full text-sm hover:bg-white hover:text-black transition">
                Pricing
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Ultra smooth gradient transition */}
      <div className="w-full h-[32rem] bg-gradient-to-b from-black via-[#101010] to-gray-100" />

      {/* Main content */}
      <main className="flex-1 w-full bg-white text-black">
        <section className="w-full py-20 px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-6 text-center max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
              How WrenchLoop Works
            </h2>
            <p className="text-gray-600 text-lg">
              Track your vehicle repairs, share knowledge with the community, and make better maintenance decisions.
            </p>
          </div>

          <div className="grid max-w-5xl mx-auto mt-16 gap-10 md:grid-cols-3 px-4">
            {[
              {
                title: "Track Your Vehicles",
                desc: "Add your vehicles and equipment to your garage and keep track of all maintenance and repairs.",
              },
              {
                title: "Log Repairs",
                desc: "Document repairs with detailed information, parts used, and photos to build a full repair history.",
              },
              {
                title: "Share Knowledge",
                desc: "Share repair logs publicly to help others solve problems and discover common fixes.",
              },
            ].map((f, i) => (
              <div key={i} className="space-y-3 text-center">
                <div className="text-blue-600 text-3xl font-bold">#{i + 1}</div>
                <h3 className="text-xl font-semibold">{f.title}</h3>
                <p className="text-gray-600">{f.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Final CTA */}
        <section className="w-full py-24 px-6 text-center bg-gray-50">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Ready to simplify your repairs?
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto text-lg">
            Sign up for free and take control of your maintenance—forever searchable, fully yours.
          </p>
          <Button size="lg" asChild>
            <Link href="/signup">Create Your Free Account</Link>
          </Button>
        </section>
      </main>
    </>
  )
}
