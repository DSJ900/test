import Link from "next/link"
import { Logo } from "@/components/logo"

export function Footer() {
  return (
    <footer className="w-full border-t bg-white py-6">
      <div className="w-full max-w-screen-xl mx-auto px-4 flex flex-col items-center justify-between gap-4 md:flex-row">
        <Logo />
        <p className="text-center text-sm text-gray-500 md:text-left">
          &copy; {new Date().getFullYear()} WrenchLoop. All rights reserved.
        </p>
        <div className="flex gap-4">
          <Link href="/terms" className="text-sm text-gray-500 hover:text-blue-600">
            Terms & Conditions
          </Link>
          <Link href="/privacy" className="text-sm text-gray-500 hover:text-blue-600">
            Privacy Policy
          </Link>
        </div>
      </div>
    </footer>
  )
}
