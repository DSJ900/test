"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

export function ManageBillingButton() {
  const [loading, setLoading] = useState(false)

  const handleClick = async () => {
    console.log("🟢 Manage Billing clicked")
    setLoading(true)

    try {
      const res = await fetch("/api/create-portal-session", {
        method: "POST",
      })

      const data = await res.json()
      console.log("📬 Billing API response:", data)

      if (data?.url) {
        window.location.href = data.url
      } else {
        alert("Failed to redirect to billing portal")
      }
    } catch (err) {
      console.error("❌ Billing fetch error:", err)
      alert("Something went wrong. See console.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Button variant="outline" onClick={handleClick} disabled={loading}>
      {loading ? "Redirecting..." : "Manage Billing"}
    </Button>
  )
}
