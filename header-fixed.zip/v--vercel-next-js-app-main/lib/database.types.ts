export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      assets: {
        Row: {
          id: string
          created_at: string
          user_id: string
          name: string
          make: string
          model: string
          year: number
          engine: string
          transmission: string
          notes: string | null
          vin_serial: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          user_id: string
          name: string
          make: string
          model: string
          year: number
          engine: string
          transmission: string
          notes?: string | null
          vin_serial?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          user_id?: string
          name?: string
          make?: string
          model?: string
          year?: number
          engine?: string
          transmission?: string
          notes?: string | null
          vin_serial?: string | null
        }
      }
      repair_logs: {
        Row: {
          id: string
          created_at: string
          user_id: string
          asset_id: string | null
          make: string
          model: string
          year: number
          engine: string
          transmission: string
          issue_description: string
          cause: string
          repair_notes: string | null
          tools_used: string | null
          miles_hours: number | null
          total_cost: number | null
          is_public: boolean
          thumbs_up: number
          thumbs_down: number
          is_hidden: boolean
        }
        Insert: {
          id?: string
          created_at?: string
          user_id: string
          asset_id?: string | null
          make: string
          model: string
          year: number
          engine: string
          transmission: string
          issue_description: string
          cause: string
          repair_notes?: string | null
          tools_used?: string | null
          miles_hours?: number | null
          total_cost?: number | null
          is_public?: boolean
          thumbs_up?: number
          thumbs_down?: number
          is_hidden?: boolean
        }
        Update: {
          id?: string
          created_at?: string
          user_id?: string
          asset_id?: string | null
          make?: string
          model?: string
          year?: number
          engine?: string
          transmission?: string
          issue_description?: string
          cause?: string
          repair_notes?: string | null
          tools_used?: string | null
          miles_hours?: number | null
          total_cost?: number | null
          is_public?: boolean
          thumbs_up?: number
          thumbs_down?: number
          is_hidden?: boolean
        }
      }
      maintenance_logs: {
        Row: {
          id: string
          created_at: string
          user_id: string
          asset_id: string
          maintenance_type: string
          description: string | null
          miles_hours: number
          total_cost: number | null
        }
        Insert: {
          id?: string
          created_at?: string
          user_id: string
          asset_id: string
          maintenance_type: string
          description?: string | null
          miles_hours: number
          total_cost?: number | null
        }
        Update: {
          id?: string
          created_at?: string
          user_id?: string
          asset_id?: string
          maintenance_type?: string
          description?: string | null
          miles_hours?: number
          total_cost?: number | null
        }
      }
      parts: {
        Row: {
          id: string
          log_id: string
          log_type: "repair" | "maintenance"
          part_number: string | null
          name: string
          price: number | null
        }
        Insert: {
          id?: string
          log_id: string
          log_type: "repair" | "maintenance"
          part_number?: string | null
          name: string
          price?: number | null
        }
        Update: {
          id?: string
          log_id?: string
          log_type?: "repair" | "maintenance"
          part_number?: string | null
          name?: string
          price?: number | null
        }
      }
      photos: {
        Row: {
          id: string
          log_id: string
          log_type: "repair" | "maintenance"
          url: string
          created_at: string
        }
        Insert: {
          id?: string
          log_id: string
          log_type: "repair" | "maintenance"
          url: string
          created_at?: string
        }
        Update: {
          id?: string
          log_id?: string
          log_type?: "repair" | "maintenance"
          url?: string
          created_at?: string
        }
      }
      votes: {
        Row: {
          id: string
          user_id: string
          repair_id: string
          vote_type: "up" | "down"
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          repair_id: string
          vote_type: "up" | "down"
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          repair_id?: string
          vote_type?: "up" | "down"
          created_at?: string
        }
      }
      bookmarks: {
        Row: {
          id: string
          user_id: string
          repair_id: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          repair_id: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          repair_id?: string
          created_at?: string
        }
      }
      comments: {
        Row: {
          id: string
          user_id: string
          repair_id: string
          content: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          repair_id: string
          content: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          repair_id?: string
          content?: string
          created_at?: string
        }
      }
      profiles: {
        Row: {
          id: string
          email: string
          is_commercial: boolean
          company_name: string | null
          default_public: boolean
          created_at: string
          subscription_tier: "free" | "small" | "large"
          stripe_customer_id: string | null
          subscription_id: string | null
        }
        Insert: {
          id: string
          email: string
          is_commercial?: boolean
          company_name?: string | null
          default_public?: boolean
          created_at?: string
          subscription_tier?: "free" | "small" | "large"
          stripe_customer_id?: string | null
          subscription_id?: string | null
        }
        Update: {
          id?: string
          email?: string
          is_commercial?: boolean
          company_name?: string | null
          default_public?: boolean
          created_at?: string
          subscription_tier?: "free" | "small" | "large"
          stripe_customer_id?: string | null
          subscription_id?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
