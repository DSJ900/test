import Stripe from "stripe"

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY environment variable is required")
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
  typescript: true,
})

export const PLANS = {
  free: {
    name: "Free",
    description: "Up to 5 vehicles",
    price: 0,
    features: [
      "Track up to 5 vehicles",
      "Unlimited repair logs",
      "Unlimited maintenance logs",
      "Access to community repair logs",
    ],
    priceId: "",
    maxAssets: 5,
  },
  small: {
    name: "Small Fleet",
    description: "Up to 20 vehicles",
    price: 5,
    features: [
      "Track up to 20 vehicles",
      "Unlimited repair logs",
      "Unlimited maintenance logs",
      "Access to community repair logs",
      "Priority support",
    ],
    priceId: process.env.STRIPE_STARTER_PRICE_ID!,
    maxAssets: 20,
  },
  large: {
    name: "Large Fleet",
    description: "Up to 150 vehicles",
    price: 25,
    features: [
      "Track up to 150 vehicles",
      "Unlimited repair logs",
      "Unlimited maintenance logs",
      "Access to community repair logs",
      "Priority support",
      "coming soon - AI integrated analytics",
    ],
    priceId: process.env.STRIPE_PRO_PRICE_ID!,
    maxAssets: 150,
  },
}
