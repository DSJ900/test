import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { cache } from "react"
import type { Database } from "@/lib/database.types"

export const createServerSupabaseClient = cache(() => {
  const cookieStore = cookies()
  return createServerComponentClient<Database>({ cookies: () => cookieStore })
})

export async function getSession() {
  const supabase = createServerSupabaseClient()
  try {
    const {
      data: { session },
    } = await supabase.auth.getSession()
    return session
  } catch (error) {
    console.error("Error:", error)
    return null
  }
}

export async function getUserDetails() {
  const supabase = createServerSupabaseClient()
  try {
    const { data: userDetails } = await supabase.from("profiles").select("*").single()
    return userDetails
  } catch (error) {
    console.error("Error:", error)
    return null
  }
}

export async function getAssetCount(userId: string) {
  const supabase = createServerSupabaseClient()
  const { count } = await supabase.from("assets").select("*", { count: "exact", head: true }).eq("user_id", userId)

  return count || 0
}

export async function getAssetLimit(tier: string) {
  switch (tier) {
    case "small":
      return 20
    case "large":
      return 150
    case "free":
    default:
      return 5
  }
}
