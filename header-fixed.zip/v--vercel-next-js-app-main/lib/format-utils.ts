export function capitalizeFirst(str: string): string {
  if (!str) return str
  return str
    .toLowerCase()
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
}

export function formatVehicleData(data: any) {
  return {
    ...data,
    make: capitalizeFirst(data.make),
    model: capitalizeFirst(data.model),
    engine: capitalizeFirst(data.engine),
    transmission: capitalizeFirst(data.transmission),
    name: capitalizeFirst(data.name),
    //added with asset_type update 6/13/26 - removed to fix form update error
    //asset_type: data.asset_type || "vehicle", 
  }
}
