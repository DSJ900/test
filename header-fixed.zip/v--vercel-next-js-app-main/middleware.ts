import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Basic Auth credentials
const validUsername = "admin"
const validPassword = "secret123"

export function middleware(request: NextRequest) {
  // Skip authentication for API routes
  if (request.nextUrl.pathname.startsWith("/api/")) {
    return NextResponse.next()
  }

  const authHeader = request.headers.get("authorization")

  if (authHeader) {
    const authValue = authHeader.split(" ")[1]
    const [user, pwd] = atob(authValue).split(":")

    if (user === validUsername && pwd === validPassword) {
      return NextResponse.next()
    }
  }

  // Return response with WWW-Authenticate header to trigger the browser's Basic Auth dialog
  return new NextResponse("Authentication required", {
    status: 401,
    headers: {
      "WWW-Authenticate": 'Basic realm="Secure Area"',
    },
  })
}

// Only run middleware on specific paths
export const config = {
  matcher: [
    /*
     * Match all paths except:
     * 1. /api routes
     * 2. /_next (Next.js internals)
     * 3. /_static (inside /public)
     * 4. /_vercel (Vercel internals)
     * 5. /favicon.ico, /sitemap.xml, /robots.txt (common static files)
     */
    "/((?!api|_next|_static|_vercel|favicon.ico|sitemap.xml|robots.txt).*)",
  ],
}
