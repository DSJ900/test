"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User, Building, Shield, Download, Trash2, CreditCard, Bookmark, MessageSquare, ThumbsUp } from "lucide-react"
import Link from "next/link"
import { ManageBillingButton } from "@/components/ManageBillingButton"


type SettingsContentProps = {
  userId: string
  userEmail: string
  userDetails: any
}

export function SettingsContent({ userId, userEmail, userDetails }: SettingsContentProps) {
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [showEmailModal, setShowEmailModal] = useState(false)
  const [formData, setFormData] = useState({
    email: userEmail,
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
    isCommercial: userDetails?.is_commercial || false,
    companyName: userDetails?.company_name || "",
    defaultPublic: userDetails?.default_public ?? false,
  })

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const { name, value, type, checked } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))
  }

  async function handleUpdateProfile() {
    setLoading(true)
    try {
      if (formData.isCommercial && !formData.companyName.trim()){
        throw new Error("Company name is required for commercial accounts")
      }

      const { error } = await supabase
        .from("profiles")
        .update({
          is_commercial: formData.isCommercial,
          company_name: formData.isCommercial ? formData.companyName : null,
          default_public: formData.defaultPublic,
        })
        .eq("id", userId)

      if (error) throw error

      toast({
        title: "Success",
        description: "Profile updated successfully.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update profile.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  async function handleChangeEmail() {
    if (!formData.currentPassword) {
      toast({
        title: "Error",
        description: "Current password is required to change email.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const { error } = await supabase.auth.updateUser({
        email: formData.email,
        password: formData.currentPassword,
      })

      if (error) throw error

      toast({
        title: "Success",
        description: "Email update initiated. Check your new email for confirmation.",
      })
      setShowEmailModal(false)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update email.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  async function handleChangePassword() {
    if (formData.newPassword !== formData.confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords do not match.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const { error } = await supabase.auth.updateUser({
        password: formData.newPassword,
      })

      if (error) throw error

      toast({
        title: "Success",
        description: "Password updated successfully.",
      })
      setShowPasswordModal(false)
      setFormData((prev) => ({
        ...prev,
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      }))
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update password.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  async function handleDownloadData() {
    setLoading(true)
    try {
      // Fetch all user data
      const [
        { data: assets },
        { data: repairLogs },
        { data: maintenanceLogs },
        { data: bookmarks },
        { data: comments },
        { data: votes },
      ] = await Promise.all([
        supabase.from("assets").select("*").eq("id", userId),
        supabase.from("repair_logs").select("*").eq("id", userId),
        supabase.from("maintenance_logs").select("*").eq("id", userId),
        supabase.from("bookmarks").select("*").eq("id", userId),
        supabase.from("comments").select("*").eq("id", userId),
        supabase.from("votes").select("*").eq("id", userId),
      ])

      const userData = {
        profile: userDetails,
        assets: assets || [],
        repairLogs: repairLogs || [],
        maintenanceLogs: maintenanceLogs || [],
        bookmarks: bookmarks || [],
        comments: comments || [],
        votes: votes || [],
        exportDate: new Date().toISOString(),
      }

      // Create and download CSV
      const csvContent = [
        "Data Type,Count",
        `Assets,${assets?.length || 0}`,
        `Repair Logs,${repairLogs?.length || 0}`,
        `Maintenance Logs,${maintenanceLogs?.length || 0}`,
        `Bookmarks,${bookmarks?.length || 0}`,
        `Comments,${comments?.length || 0}`,
        `Votes,${votes?.length || 0}`,
      ].join("\n")

      const blob = new Blob([csvContent], { type: "text/csv" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `wrenchloop-data-${new Date().toISOString().split("T")[0]}.csv`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      toast({
        title: "Success",
        description: "Data exported successfully.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to export data.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  async function handleDeleteAccount() {
  setLoading(true)
  try {
    const deletedId = '00000000-0000-0000-0000-000000000000' // or your chosen placeholder user ID

    // Step 1: Mark profile as deleted
    const { error: profileError } = await supabase.from('profiles').update({
      is_deleted: true,
      deleted_at: new Date().toISOString()
    }).eq('id', userId)

    if (profileError) throw profileError

    // Step 2: Reassign public content ownership (e.g. repair_logs)
    const { error: transferError } = await supabase.from('repair_logs').update({
      original_owner_id: userId,
      id: deletedId
    }).eq('id', userId)
      .eq('is_public', true)

    if (transferError) throw transferError

    // Step 3: Sign out and notify user
    toast({
      title: "Account deletion scheduled",
      description: "Your account will be permanently deleted in 90 days. You can restore it anytime before then.",
    })

    await supabase.auth.signOut()
    router.push("/")
  } catch (error: any) {
    toast({
      title: "Error",
      description: error.message || "Failed to delete account.",
      variant: "destructive",
    })
  } finally {
    setLoading(false)
  }
 }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-gray-500">Manage your account and preferences</p>
      </div>

      <Tabs defaultValue="account" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
        </TabsList>

        <TabsContent value="account" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Account Information
              </CardTitle>
              <CardDescription>Update your account details and security settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Email Address</Label>
                  <div className="flex gap-2">
                    <Input value={userEmail} disabled />
                    <Button variant="outline" onClick={() => setShowEmailModal(true)}>
                      Change
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Password</Label>
                  <div className="flex gap-2">
                    <Input value="••••••••" disabled />
                    <Button variant="outline" onClick={() => setShowPasswordModal(true)}>
                      Change
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Account Type
              </CardTitle>
              <CardDescription>Switch between personal and commercial account</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="commercial"
                  checked={formData.isCommercial}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, isCommercial: checked }))}
                />
                <Label htmlFor="commercial">Commercial Account</Label>
              </div>
              {formData.isCommercial && (
                <div className="space-y-2">
                  <Label htmlFor="companyName">Company Name</Label>
                  <Input
                    id="companyName"
                    name="companyName"
                    value={formData.companyName}
                    onChange={handleInputChange}
                    placeholder="Enter company name"
                  />
                </div>
              )}
              <Button onClick={handleUpdateProfile} disabled={loading}>
                {loading ? "Updating..." : "Update Profile"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Privacy Settings
              </CardTitle>
              <CardDescription>Control the default visibility of your repair logs</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="defaultPublic"
                  checked={formData.defaultPublic}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, defaultPublic: checked }))}
                />
                <Label htmlFor="defaultPublic">Make new repairs public by default</Label>
              </div>
              <p className="text-sm text-gray-500">
                When enabled, new repair logs will be visible to the public by default. You can always change this for
                individual repairs.
              </p>
              <Button onClick={handleUpdateProfile} disabled={loading}>
                {loading ? "Updating..." : "Update Preferences"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bookmark className="h-5 w-5" />
                  Bookmarked Repairs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500 mb-4">View repairs you've bookmarked for reference</p>
                <Link href="/bookmarks">
                  <Button variant="outline" className="w-full">
                    View Bookmarks
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Community Notes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500 mb-4">See comments you've left on repair logs</p>
                <Link href="/comments">
                  <Button variant="outline" className="w-full">
                    View Comments
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ThumbsUp className="h-5 w-5" />
                  Votes & Likes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500 mb-4">Review repairs you've voted on</p>
                <Link href="/votes">
                  <Button variant="outline" className="w-full">
                    View Votes
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5" />
                Data Export
              </CardTitle>
              <CardDescription>Download all your data in CSV format</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500 mb-4">
                Export all your vehicles, repair logs, maintenance records, and activity data.
              </p>
              <Button onClick={handleDownloadData} disabled={loading}>
                {loading ? "Exporting..." : "Download My Data"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Subscription Management
              </CardTitle>
              <CardDescription>Manage your subscription and billing information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Current Plan</p>
                  <p className="text-sm text-gray-500 capitalize">
                    {userDetails?.subscription_tier || "free"} tier
                  </p>

                {userDetails?.subscription_tier === "small" && userDetails?.starter_for_life && (
                  <p className="text-sm text-green-600 mt-1">
                   ✅ You have the <strong>Small Fleet plan for life!</strong> 
                  </p>
                )}
                </div>
                <div className="flex gap-2">
                  <Link href="/pricing">
                    <Button variant="outline">Change Plan</Button>
                  </Link>
                  {userDetails?.stripe_customer_id && <ManageBillingButton />}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-red-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <Trash2 className="h-5 w-5" />
                Danger Zone
              </CardTitle>
              <CardDescription>Permanently delete your account and all associated data</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500 mb-4">
                Your account will be deactivated for 90 days. After that, all your private vehicles, repair logs, maintenance records, and account data will be permanently deleted.
              </p>
              <Button variant="destructive" onClick={() => setShowDeleteModal(true)}>
                Delete Account
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Change Email Modal */}
      <Dialog open={showEmailModal} onOpenChange={setShowEmailModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Email Address</DialogTitle>
            <DialogDescription>Enter your current password and new email address</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="newEmail">New Email Address</Label>
              <Input id="newEmail" name="email" type="email" value={formData.email} onChange={handleInputChange} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currentPasswordEmail">Current Password</Label>
              <Input
                id="currentPasswordEmail"
                name="currentPassword"
                type="password"
                value={formData.currentPassword}
                onChange={handleInputChange}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEmailModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleChangeEmail} disabled={loading}>
              {loading ? "Updating..." : "Update Email"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Change Password Modal */}
      <Dialog open={showPasswordModal} onOpenChange={setShowPasswordModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Password</DialogTitle>
            <DialogDescription>Enter your new password</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="newPassword">New Password</Label>
              <Input
                id="newPassword"
                name="newPassword"
                type="password"
                value={formData.newPassword}
                onChange={handleInputChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm New Password</Label>
              <Input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={handleInputChange}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPasswordModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleChangePassword} disabled={loading}>
              {loading ? "Updating..." : "Update Password"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Account Modal */}
      <Dialog open={showDeleteModal} onOpenChange={setShowDeleteModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Account</DialogTitle>
            <DialogDescription>
              Are you absolutely sure you want to delete your account? After 90 days, this action becomes permanent and cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="bg-red-50 p-4 rounded-lg">
            <p className="text-sm text-red-800">This will permanently delete:</p>
            <ul className="text-sm text-red-800 list-disc list-inside mt-2">
              <li>All your vehicles and equipment</li>
              <li>All private repair and maintenance logs</li>
              <li>All comments and votes</li>
              <li>Your account and profile data</li>
            </ul>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteModal(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteAccount} disabled={loading}>
              {loading ? "Deleting..." : "Delete Account"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
