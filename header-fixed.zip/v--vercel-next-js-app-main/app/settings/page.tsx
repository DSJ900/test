import { redirect } from "next/navigation"
import { getSession, getUserDetails } from "@/lib/supabase-server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { SettingsContent } from "./settings-content"

export default async function SettingsPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  const userDetails = await getUserDetails()

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <SettingsContent userId={session.user.id} userEmail={session.user.email || ""} userDetails={userDetails} />
      </main>
      <Footer />
    </div>
  )
}
