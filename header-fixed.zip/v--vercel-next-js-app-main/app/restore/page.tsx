"use client"

import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { useSupabase } from "@/lib/supabase-provider"
import { useToast } from "@/hooks/use-toast"

export default function RestorePage() {
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const getUser = async () => {
      const { data, error } = await supabase.auth.getUser()
      if (error || !data?.user) {
        router.push("/login")
      } else {
        setUser(data.user)
      }
    }

    getUser()
  }, [router, supabase])

  const handleRestore = async () => {
    if (!user?.id) return

    setLoading(true)

    try {
      // Step 1: Unmark profile as deleted
      const { error: profileError } = await supabase.from("profiles").update({
        is_deleted: false,
        deleted_at: null
      }).eq("id", user.id)

      if (profileError) throw profileError

      // Step 2: Restore ownership of public logs
      const { error: logError } = await supabase.from("repair_logs").update({
        id: user.id
      }).eq("original_owner_id", user.id)
        .eq("id", "00000000-0000-0000-0000-000000000000")

      if (logError) throw logError

      toast({
        title: "Account Restored",
        description: "Your account and data have been restored.",
      })

      router.push("/dashboard")
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to restore account.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 text-center">
      <h1 className="text-2xl font-bold mb-2">Restore Your Account</h1>
      <p className="text-gray-500 max-w-md mb-6">
        You previously scheduled your account for deletion. If you'd like to cancel this and fully restore your account
        and saved data, click below. This action must be taken within 90 days of deactivation.
      </p>
      <Button onClick={handleRestore} disabled={loading}>
        {loading ? "Restoring..." : "Restore My Account"}
      </Button>
    </div>
  )
}