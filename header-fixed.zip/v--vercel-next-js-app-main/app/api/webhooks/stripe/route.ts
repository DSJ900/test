import { type NextRequest, NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"
import { createClient } from "@supabase/supabase-js"
import type Stripe from "stripe"

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get("stripe-signature")!

    let event: Stripe.Event

    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
    } catch (err: any) {
      console.error("❌ Webhook signature verification failed:", err.message)
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY! // must be stored securely in .env
    )

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session
        const userId = session.metadata?.userId

        if (!userId) {
          console.error("❌ No userId in session metadata")
          return NextResponse.json({ error: "Missing userId" }, { status: 400 })
        }

        const subscription = await stripe.subscriptions.retrieve(session.subscription as string)
        const priceId = subscription.items.data[0].price.id

        let tier = "free"
        if (priceId === process.env.STRIPE_STARTER_PRICE_ID) tier = "small"
        else if (priceId === process.env.STRIPE_PRO_PRICE_ID) tier = "large"

        const { error: updateError } = await supabase
          .from("profiles")
          .update({
            subscription_tier: tier,
            subscription_id: subscription.id,
            stripe_customer_id: session.customer as string,
          })
          .eq("id", userId)

        if (updateError) {
          console.error("❌ Failed to update profile:", updateError)
        }

        break
      }
      
      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription
        const customerId = subscription.customer as string
        
        // 🔄 Get the Stripe customer to retrieve stored metadata (userId)
        const customer = await stripe.customers.retrieve(customerId) as Stripe.Customer
        const userId = customer.metadata?.userId
            
        if (!userId) {
          console.warn("⚠️ Stripe customer has no userId metadata:", customerId)
          return NextResponse.json({ error: "No userId metadata" }, { status: 400 })
        }
        
        // 🔎 Lookup Supabase profile by internal userId (NOT by customer ID anymore)
          
        const { data: profile, error } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", userId)
          .single()
          
        if (error || !profile) {
          console.error("❌ No profile found for userId from metadata:", userId)
          return NextResponse.json({ error: "Profile not found" }, { status: 404 })
        }
        
        // 🎯 Determine subscription tier based on price ID
        
        let tier = "free"
        const priceId = subscription.items.data[0]?.price?.id
        
        if (!priceId) {
          console.warn("⚠️ No price ID found in subscription:", subscription.id)
        } else {
        if (priceId === process.env.STRIPE_STARTER_PRICE_ID) tier = "small"
        else if (priceId === process.env.STRIPE_PRO_PRICE_ID) tier = "large"
        
        // 💾 Update the Supabase profile
          
        const { error: updateError } = await supabase
        .from("profiles")
        .update({
          subscription_tier: tier,
          subscription_id: subscription.id,
        })
        .eq("id", profile.id)

      if (updateError) {
        console.error("❌ Failed to update profile after subscription change:", updateError)
      }
    }
        
      break
    }


      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription
        const customerId = subscription.customer as string

        const { data: profile, error } = await supabase
          .from("profiles")
          .select("*")
          .eq("stripe_customer_id", customerId)
          .single()

        if (error || !profile) {
          console.error("❌ No profile found for customer:", customerId)
          return NextResponse.json({ error: "Profile not found" }, { status: 404 })
        }

        const newTier = profile.starter_for_life ? "small" : "free"
        
        const { error: updateError } = await supabase
        .from("profiles")
        .update({
          subscription_tier: newTier,
          subscription_id: null,
        })
        .eq("id", profile.id)

        if (updateError) {
          console.error("❌ Failed to downgrade profile:", updateError)
        } else {
          console.log('✅ User ${profile.id} downgraded to ${newTier}')
        }

        break
      }

      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (error: any) {
    console.error("🔥 Webhook error:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

