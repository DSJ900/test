import { type NextRequest, NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"
import { createServerSupabaseClient } from "@/lib/supabase-server"

export async function POST(request: NextRequest) {
  try {
    const { priceId, userId } = await request.json()

    if (!priceId || !userId) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    const supabase = createServerSupabaseClient()

    // Get user profile
    const { data: profile, error: profileError } = await supabase.from("profiles").select("*").eq("id", userId).single()

    if (profileError || !profile) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    let customerId = profile.stripe_customer_id

    // Create Stripe customer if doesn't exist
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: profile.email,
        metadata: {
          userId: userId,
        },
      })

      customerId = customer.id

      // Update profile with customer ID
      await supabase
      .from("profiles")
      .update({ stripe_customer_id: customerId })
      .eq("id", userId)
    }

    // ✅ Get origin with fallback
    const origin =
      request.headers.get("origin") ||
      process.env.NEXT_PUBLIC_APP_URL ||
      "https://wrenchloop.vercel.app"

    console.log("✅ Stripe checkout using origin:", origin)

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ["card"],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: `${origin}/dashboard?success=true`,
      cancel_url: `${origin}/pricing?canceled=true`,
      metadata: {
        userId: userId,
      },
      customer_update:{
        address: 'auto',
        name: 'auto',
      },
    })

    return NextResponse.json({ sessionId: session.id })
  } catch (error: any) {
    console.error("🔥 Stripe session error:", {
      message: error.message,
      full: error,
    })
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
