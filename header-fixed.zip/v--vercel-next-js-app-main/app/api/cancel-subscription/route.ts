import { NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"
import { createClient } from "@supabase/supabase-js"

export async function POST(req: Request) {
  try {
    const { userId } = await req.json()

    if (!userId) {
      return NextResponse.json({ error: "Missing userId" }, { status: 400 })
    }

    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!
    )

    // Get user profile including lifetime flag
    const { data: profile, error } = await supabase
      .from("profiles")
      .select("subscription_id, starter_for_life")
      .eq("id", userId)
      .single()

    if (error || !profile?.subscription_id) {
      return NextResponse.json({ error: "Subscription not found" }, { status: 404 })
    }

    const subscription = await stripe.subscriptions.retrieve(profile.subscription_id)

    if (subscription.status !== "active") {
      return NextResponse.json({ error: "Subscription is already canceled" }, { status: 400 })
    }

    // Set Stripe to cancel at period end
    await stripe.subscriptions.update(profile.subscription_id, {
      cancel_at_period_end: true,
    })

    // Update user's Supabase profile now with fallback tier
    const fallbackTier = profile.starter_for_life ? "small" : "free"

    const { error: updateError } = await supabase
      .from("profiles")
      .update({
        subscription_tier: fallbackTier,
        subscription_id: profile.subscription_id, // still keep until period end
      })
      .eq("id", userId)

    if (updateError) {
      console.error("❌ Failed to update profile on cancel:", updateError)
    }

    return NextResponse.json({ success: true })
  } catch (err: any) {
    console.error("❌ Cancel subscription error:", err)
    return NextResponse.json({ error: err.message || "Server error" }, { status: 500 })
  }
}