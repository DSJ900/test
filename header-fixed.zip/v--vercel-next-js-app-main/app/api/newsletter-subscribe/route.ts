// app/api/newsletter-subscribe/route.ts

import { NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  const body = await req.json()
  const email = (body?.email || "").trim().toLowerCase()

  console.log("📩 Incoming email:", email)

  if (!email || !email.includes("@")) {
    console.error("🚫 Invalid or missing email.")
    return NextResponse.json({ error: "Invalid email" }, { status: 400 })
  }

  const token = process.env.BUTTONDOWN_API_KEY
  if (!token) {
    console.error("🚨 BUTTONDOWN_API_KEY is missing or undefined!")
    return NextResponse.json({ error: "Server misconfiguration" }, { status: 500 })
  }

  console.log("🧪 BUTTONDOWN_API_KEY loaded:", token.slice(0, 5) + "...")

  try {
    const res = await fetch("https://api.buttondown.email/v1/subscribers", {
      method: "POST",
      headers: {
        Authorization: `Token ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email_address: email, // ✅ corrected field name
        tags: ["wrenchloop-signup"],
      }),
    })

    const text = await res.text()
    console.log("📬 Buttondown response body:", text)

    if (!res.ok) {
      console.error("❌ Buttondown response not OK:", res.status)
      return NextResponse.json(
        { error: "Failed to subscribe", details: text },
        { status: 500 }
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("🔥 Network or fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

