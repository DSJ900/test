import { createClient } from "@supabase/supabase-js"
import { NextResponse } from "next/server"

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET() {
  try {
    const { data: repairData, error: repairError } = await supabase
      .from("repair_logs")
      .select("reference_id, created_at")
      .order("created_at", { ascending: false })
      .limit(1)

    const { data: maintenanceData, error: maintenanceError } = await supabase
      .from("maintenance_logs")
      .select("reference_id, created_at")
      .order("created_at", { ascending: false })
      .limit(1)

    if (repairError || maintenanceError) {
      console.error("Error fetching latest reference_id")
      return NextResponse.json({ error: "Failed to fetch logs" }, { status: 500 })
    }

    const latestRepairId = repairData?.[0]?.reference_id?.replace("WL-", "")
    const latestMaintenanceId = maintenanceData?.[0]?.reference_id?.replace("WL-", "")

    const maxId = Math.max(
      parseInt(latestRepairId || "0"),
      parseInt(latestMaintenanceId || "0")
    )

    const nextNumber = String(maxId + 1).padStart(6, "0")
    const referenceId = `WL-${nextNumber}`

    return NextResponse.json({ referenceId })
  } catch (err) {
    console.error("Unexpected error:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}