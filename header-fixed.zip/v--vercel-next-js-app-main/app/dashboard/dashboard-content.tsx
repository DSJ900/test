"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { Car, Plus, Wrench, Pencil, Trash2 } from "lucide-react"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import { formatVehicleData } from "@/lib/format-utils"

type Asset = {
  id: string
  asset_type: string
  name: string
  make: string
  model: string
  year: number
  engine: string
  transmission: string
  notes: string | null
  vin_serial: string | null
  created_at: string
}

type DashboardContentProps = {
  userId: string
  userEmail: string
  assetCount: number
  assetLimit: number
  userDetails: any
}

export function DashboardContent({ userId, userEmail, assetCount, assetLimit, userDetails }: DashboardContentProps) {
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [assets, setAssets] = useState<Asset[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddAssetModal, setShowAddAssetModal] = useState(false)
  const [showEditAssetModal, setShowEditAssetModal] = useState(false)
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false)
  const [showLogRepairModal, setShowLogRepairModal] = useState(false)
  const [currentAsset, setCurrentAsset] = useState<Asset | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    make: "",
    model: "",
    year: new Date().getFullYear(),
    asset_type: "Vehicle",
    engine: "",
    transmission: "",
    notes: "",
    vin_serial: "",
  })

  useEffect(() => {
    fetchAssets()
  }, [])

  async function fetchAssets() {
    setLoading(true)
    try {
      const { data, error } = await supabase.from("assets").select("*").order("created_at", { ascending: false })

      if (error) {
        throw error
      }

      setAssets(data || [])
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to fetch assets.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  async function handleAddAsset(e: React.FormEvent) {
    e.preventDefault()

    if (assetCount >= assetLimit) {
      toast({
        title: "Asset Limit Reached",
        description: `You've reached your limit of ${assetLimit} assets. Please upgrade your plan to add more.`,
        variant: "destructive",
      })
      setShowAddAssetModal(false)
      return
    }

    try {
      const formattedData = formatVehicleData({
        user_id: userId,
        name: formData.name,
        asset_type: formData.asset_type,
        make: formData.make,
        model: formData.model,
        year: Number.parseInt(formData.year.toString()),
        engine: formData.engine,
        transmission: formData.transmission,
        notes: formData.notes || null,
        vin_serial: formData.vin_serial || null,
      })

      const { data, error } = await supabase.from("assets").insert([formattedData]).select()

      if (error) {
        throw error
      }

      toast({
        title: "Success",
        description: "Asset added successfully.",
      })

      setAssets((prev) => [data[0], ...prev])
      setShowAddAssetModal(false)
      resetForm()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to add asset.",
        variant: "destructive",
      })
    }
  }

  async function handleEditAsset(e: React.FormEvent) {
    e.preventDefault()
    if (!currentAsset) return

    try {
      const formattedData = formatVehicleData({
        name: formData.name,
        asset_type: formData.asset_type,
        make: formData.make,
        model: formData.model,
        year: Number.parseInt(formData.year.toString()),
        engine: formData.engine,
        transmission: formData.transmission,
        notes: formData.notes || null,
        vin_serial: formData.vin_serial || null,
      })

      const { data, error } = await supabase.from("assets").update(formattedData).eq("id", currentAsset.id).select()

      if (error) {
        throw error
      }

      toast({
        title: "Success",
        description: "Asset updated successfully.",
      })

      setAssets((prev) => prev.map((asset) => (asset.id === currentAsset.id ? data[0] : asset)))
      setShowEditAssetModal(false)
      resetForm()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update asset.",
        variant: "destructive",
      })
    }
  }

  async function handleDeleteAsset() {
    if (!currentAsset) return

    try {
      const { error } = await supabase.from("assets").delete().eq("id", currentAsset.id)

      if (error) {
        throw error
      }

      toast({
        title: "Success",
        description: "Asset deleted successfully.",
      })

      setAssets((prev) => prev.filter((asset) => asset.id !== currentAsset.id))
      setShowDeleteConfirmModal(false)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete asset.",
        variant: "destructive",
      })
    }
  }

  function resetForm() {
    setFormData({
      name: "",
      asset_type: "",
      make: "",
      model: "",
      year: new Date().getFullYear(),
      engine: "",
      transmission: "",
      notes: "",
      vin_serial: "",
    })
    setCurrentAsset(null)
  }

  function openEditModal(asset: Asset) {
    setCurrentAsset(asset)
    setFormData({
      name: asset.name,
      asset_type: asset.asset_type,
      make: asset.make,
      model: asset.model,
      year: asset.year,
      engine: asset.engine,
      transmission: asset.transmission,
      notes: asset.notes || "",
      vin_serial: asset.vin_serial || "",
    })
    setShowEditAssetModal(true)
  }

  function openDeleteModal(asset: Asset) {
    setCurrentAsset(asset)
    setShowDeleteConfirmModal(true)
  }

  function openLogRepairModal(asset: Asset) {
    setCurrentAsset(asset)
    setShowLogRepairModal(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-gray-500">Manage your vehicles and equipment</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button onClick={() => setShowAddAssetModal(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add New Asset
          </Button>
          <Link href="/logs/new">
            <Button variant="outline">
              <Wrench className="mr-2 h-4 w-4" /> Log Repair or Maintenance
            </Button>
          </Link>
        </div>
      </div>

      {assetCount >= assetLimit && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div>
                <h3 className="font-semibold">Asset Limit Reached</h3>
                <p className="text-sm text-gray-600">
                  You've reached your limit of {assetLimit} assets. Upgrade your plan to add more vehicles or equipment.
                </p>
              </div>
              <Link href="/pricing" className="ml-auto">
                <Button variant="outline" size="sm">
                  Upgrade Plan
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {loading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="bg-gray-100 h-24" />
              <CardContent className="py-4">
                <div className="h-4 bg-gray-100 rounded mb-2" />
                <div className="h-4 bg-gray-100 rounded w-2/3" />
              </CardContent>
            </Card>
          ))
        ) : assets.length > 0 ? (
          assets.map((asset) => (
            <Card key={asset.id}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{asset.name}</span>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" onClick={() => openEditModal(asset)}>
                      <Pencil className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => openDeleteModal(asset)}>
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </div>
                </CardTitle>
                <CardDescription>
                  {asset.year} {asset.make} {asset.model}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="font-medium">Engine:</span> {asset.engine}
                  </div>
                  <div>
                    <span className="font-medium">Transmission:</span> {asset.transmission}
                  </div>
                  {asset.vin_serial && (
                    <div className="col-span-2">
                      <span className="font-medium">VIN/Serial:</span> {asset.vin_serial}
                    </div>
                  )}
                  {asset.notes && (
                    <div className="col-span-2">
                      <span className="font-medium">Notes:</span> {asset.notes}
                    </div>
                  )}
                  <div className="col-span-2">
                    <span className="font-medium">Added:</span> {formatDate(asset.created_at)}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" size="sm" onClick={() => openLogRepairModal(asset)}>
                  <Wrench className="mr-2 h-4 w-4" /> Log Repair
                </Button>
                <Link href={`/analytics?asset=${asset.id}`}>
                  <Button variant="ghost" size="sm">
                    View Analytics
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))
        ) : (
          <Card className="col-span-full">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Car className="h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-medium mb-2">No Assets Yet</h3>
              <p className="text-gray-500 text-center mb-4">Add your first vehicle or equipment to get started.</p>
              <Button onClick={() => setShowAddAssetModal(true)}>
                <Plus className="mr-2 h-4 w-4" /> Add New Asset
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Add Asset Modal */}
      <Dialog open={showAddAssetModal} onOpenChange={setShowAddAssetModal}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add New Asset</DialogTitle>
            <DialogDescription>Add a new vehicle or piece of equipment to your garage.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddAsset}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="name">Asset Name</Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="asset_type">Asset Type</Label>
                  <select
                    id="asset_type"
                    name="asset_type"
                    value={formData.asset_type || "Vehicle"}
                    onChange={(e) => setFormData((prev) => ({ ...prev, asset_type: e.target.value }))}
                    className="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    >
                    <option value="Vehicle">Vehicle</option>
                    <option value="Equipment">Equipment</option>
                  </select>
                </div>  
                <div>
                  <Label htmlFor="make">Make</Label>
                  <Input id="make" name="make" value={formData.make} onChange={handleInputChange} required />
                </div>
                <div>
                  <Label htmlFor="model">Model</Label>
                  <Input id="model" name="model" value={formData.model} onChange={handleInputChange} required />
                </div>
                <div>
                  <Label htmlFor="year">Year</Label>
                  <Input
                    id="year"
                    name="year"
                    type="number"
                    value={formData.year}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="engine">Engine</Label>
                  <Input id="engine" name="engine" value={formData.engine} onChange={handleInputChange} required />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="transmission">Transmission</Label>
                  <Input
                    id="transmission"
                    name="transmission"
                    value={formData.transmission}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="vin_serial">VIN/Serial Number (Optional)</Label>
                  <Input id="vin_serial" name="vin_serial" value={formData.vin_serial} onChange={handleInputChange} />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="notes">Notes (Optional)</Label>
                  <Textarea id="notes" name="notes" value={formData.notes} onChange={handleInputChange} rows={3} />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowAddAssetModal(false)}>
                Cancel
              </Button>
              <Button type="submit">Add Asset</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Asset Modal */}
      <Dialog open={showEditAssetModal} onOpenChange={setShowEditAssetModal}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Asset</DialogTitle>
            <DialogDescription>Update the details of your vehicle or equipment.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditAsset}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="edit-name">Asset Name</Label>
                  <Input id="edit-name" name="name" value={formData.name} onChange={handleInputChange} required />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="asset_type">Asset Type</Label>
                  <select
                    id="asset_type"
                    name="asset_type"
                    value={formData.asset_type || "Vehicle"}
                    onChange={(e) => setFormData((prev) => ({ ...prev, asset_type: e.target.value }))}
                    className="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    >
                    <option value="Vehicle">Vehicle</option>
                    <option value="Equipment">Equipment</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="edit-make">Make</Label>
                  <Input id="edit-make" name="make" value={formData.make} onChange={handleInputChange} required />
                </div>
                <div>
                  <Label htmlFor="edit-model">Model</Label>
                  <Input id="edit-model" name="model" value={formData.model} onChange={handleInputChange} required />
                </div>
                <div>
                  <Label htmlFor="edit-year">Year</Label>
                  <Input
                    id="edit-year"
                    name="year"
                    type="number"
                    value={formData.year}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-engine">Engine</Label>
                  <Input id="edit-engine" name="engine" value={formData.engine} onChange={handleInputChange} required />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="edit-transmission">Transmission</Label>
                  <Input
                    id="edit-transmission"
                    name="transmission"
                    value={formData.transmission}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="edit-vin_serial">VIN/Serial Number (Optional)</Label>
                  <Input
                    id="edit-vin_serial"
                    name="vin_serial"
                    value={formData.vin_serial}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="edit-notes">Notes (Optional)</Label>
                  <Textarea id="edit-notes" name="notes" value={formData.notes} onChange={handleInputChange} rows={3} />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowEditAssetModal(false)}>
                Cancel
              </Button>
              <Button type="submit">Update Asset</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Modal */}
      <Dialog open={showDeleteConfirmModal} onOpenChange={setShowDeleteConfirmModal}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this asset? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteConfirmModal(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteAsset}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Log Repair Modal */}
      <Dialog open={showLogRepairModal} onOpenChange={setShowLogRepairModal}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Log Repair or Maintenance</DialogTitle>
            <DialogDescription>Choose what you want to log for {currentAsset?.name}.</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-4">
            <Link href={`/logs/new?type=repair&asset=${currentAsset?.id}`} onClick={() => setShowLogRepairModal(false)}>
              <Button className="w-full">Log a Repair</Button>
            </Link>
            <Link
              href={`/logs/new?type=maintenance&asset=${currentAsset?.id}`}
              onClick={() => setShowLogRepairModal(false)}
            >
              <Button variant="outline" className="w-full">
                Log Routine Maintenance
              </Button>
            </Link>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
