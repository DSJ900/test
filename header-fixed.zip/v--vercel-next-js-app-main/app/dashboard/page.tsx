import { redirect } from "next/navigation"
import {
  getSession,
  getUserDetails,
  getAssetCount,
  getAssetLimit,
} from "@/lib/supabase-server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { DashboardContent } from "./dashboard-content"

export default async function DashboardPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  const userDetails = await getUserDetails()

  // ✅ Soft-deleted user check
  if (userDetails?.is_deleted) {
    redirect("/restore")
  }

  const assetCount = await getAssetCount(session.user.id)
  const assetLimit = await getAssetLimit(userDetails?.subscription_tier || "free")

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <DashboardContent
          userId={session.user.id}
          userEmail={session.user.email || ""}
          assetCount={assetCount}
          assetLimit={assetLimit}
          userDetails={userDetails}
        />
      </main>
      <Footer />
    </div>
  )
}