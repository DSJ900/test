// page.tsx
import { notFound, redirect } from "next/navigation"
import { getSession, createServerSupabaseClient } from "@/lib/supabase-server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { LogViewContent } from "./log-view-content"

export default async function LogViewPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  const id = searchParams.id as string
  const type = searchParams.type as "repair" | "maintenance"

  if (!id || !type) {
    notFound()
  }

  const supabase = createServerSupabaseClient()

  let log

  if (type === "repair") {
    const { data, error } = await supabase
      .from("repair_logs")
      .select("*, asset:assets(name), repair_parts(*), repair_photos(*)")
      .eq("id", id)
      .eq("user_id", session.user.id)
      .single()

    if (error || !data) {
      notFound()
    }

    log = data
  } else {
    const { data, error } = await supabase
      .from("maintenance_logs")
      .select("*, asset:assets(name, make, model, year), maintenance_parts(*), maintenance_photos(*)")
      .eq("id", id)
      .eq("user_id", session.user.id)
      .single()

    if (error || !data) {
      notFound()
    }

    log = data
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <LogViewContent log={log} type={type} />
      </main>
      <Footer />
    </div>
  )
}
