"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatCurrency, formatDate } from "@/lib/utils"
import { ArrowLeft, Edit, Printer, Wrench, Car, Calendar, DollarSign } from "lucide-react"
import Link from "next/link"

type LogViewContentProps = {
  log: any
  type: "repair" | "maintenance"
}

export function LogViewContent({ log, type }: LogViewContentProps) {
  const handlePrint = () => {
    window.print()
  }

  const photos = type === "repair" ? log.repair_photos : log.maintenance_photos

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/logs">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Logs
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">{type === "repair" ? log.issue_description : log.maintenance_type}</h1>
            <p className="text-gray-500">
              {type === "repair"
                ? `${log.year} ${log.make} ${log.model}${log.asset?.name ? ` - ${log.asset.name}` : ""}`
                : `${log.asset.year} ${log.asset.make} ${log.asset.model} - ${log.asset.name}`}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Link href={`/logs/edit?id=${log.id}&type=${type}`}>
            <Button variant="outline">
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
          </Link>
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wrench className="h-5 w-5" />
                {type === "repair" ? "Repair Details" : "Maintenance Details"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {type === "repair" ? (
                <>
                  <div>
                    <h4 className="font-medium">Issue Description</h4>
                    <p className="text-gray-600">{log.issue_description}</p>
                  </div>
                  <div>
                    <h4 className="font-medium">Root Cause</h4>
                    <p className="text-gray-600">{log.cause}</p>
                  </div>
                  {log.repair_notes && (
                    <div>
                      <h4 className="font-medium">Repair Notes</h4>
                      <p className="text-gray-600">{log.repair_notes}</p>
                    </div>
                  )}
                  {log.tools_used && (
                    <div>
                      <h4 className="font-medium">Tools Used</h4>
                      <p className="text-gray-600">{log.tools_used}</p>
                    </div>
                  )}
                  <div>
                    <h4 className="font-medium">Visibility</h4>
                    <Badge variant={log.is_public ? "default" : "secondary"}>
                      {log.is_public ? "Public" : "Private"}
                    </Badge>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <h4 className="font-medium">Maintenance Type</h4>
                    <p className="text-gray-600">{log.maintenance_type}</p>
                  </div>
                  {log.description && (
                    <div>
                      <h4 className="font-medium">Description</h4>
                      <p className="text-gray-600">{log.description}</p>
                    </div>
                  )}
                  <div>
                    <h4 className="font-medium">Miles/Hours</h4>
                    <p className="text-gray-600">{log.miles_hours.toLocaleString()}</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {log.parts && log.parts.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Parts Used</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {log.parts.map((part: any) => (
                    <div key={part.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">{part.name}</p>
                        {part.part_number && <p className="text-sm text-gray-500">Part #: {part.part_number}</p>}
                      </div>
                      {part.price && <Badge variant="secondary">{formatCurrency(part.price)}</Badge>}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {photos && photos.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Photos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {photos.map((photo: any) => (
                    <img
                      key={photo.id}
                      src={photo.url || "/placeholder.svg"}
                      alt="Log photo"
                      className="w-full h-32 object-cover rounded-lg"
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="h-5 w-5" />
                Vehicle Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {type === "repair" ? (
                <>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Make:</span>
                    <span className="font-medium">{log.make}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Model:</span>
                    <span className="font-medium">{log.model}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Year:</span>
                    <span className="font-medium">{log.year}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Engine:</span>
                    <span className="font-medium">{log.engine}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Transmission:</span>
                    <span className="font-medium">{log.transmission}</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Vehicle:</span>
                    <span className="font-medium">{log.asset.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Make:</span>
                    <span className="font-medium">{log.asset.make}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Model:</span>
                    <span className="font-medium">{log.asset.model}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Year:</span>
                    <span className="font-medium">{log.asset.year}</span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Cost Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {log.total_cost ? (
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Cost:</span>
                  <span className="font-medium text-lg">{formatCurrency(log.total_cost)}</span>
                </div>
              ) : (
                <p className="text-gray-500">No cost information available</p>
              )}
              {type === "repair" && log.miles_hours && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Miles/Hours:</span>
                  <span className="font-medium">{log.miles_hours.toLocaleString()}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                {type === "repair" ? "Repair" : "Maintenance"} completed on {formatDate(log.created_at)}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
