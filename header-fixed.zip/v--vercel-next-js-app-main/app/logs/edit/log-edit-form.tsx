"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/lib/supabase-provider"
import { useToast } from "@/hooks/use-toast"
import { LogForm } from "../new/log-form"

export function LogEditForm({
  userId,
  id,
  type,
}: {
  userId: string
  id: string
  type: "repair" | "maintenance"
}) {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const router = useRouter()

  const [loading, setLoading] = useState(true)
  const [logData, setLogData] = useState<any>(null)

  useEffect(() => {
    async function fetchLog() {
      try {
        // 1. Fetch base log record
        const logTable = type === "repair" ? "repair_logs" : "maintenance_logs"
        const { data: log, error: logError } = await supabase
          .from(logTable)
          .select("*")
          .eq("id", id)
          .eq("user_id", userId)
          .single()
        if (logError || !log) throw logError || new Error("Log not found")

        // 2. Fetch parts from the correct table
        const partsTable = type === "repair" ? "repair_parts" : "maintenance_parts"
        const partsColumn = type === "repair" ? "repair_log_id" : "maintenance_log_id"
        const { data: parts, error: partsError } = await supabase
          .from(partsTable)
          .select("*")
          .eq(partsColumn, id)
        if (partsError) throw partsError

        // 3. Fetch photos from the correct table
        const photoTable = type === "repair" ? "repair_photos" : "maintenance_photos"
        const photoColumn = type === "repair" ? "repair_log_id" : "maintenance_log_id"
        const { data: photos, error: photosError } = await supabase
          .from(photoTable)
          .select("*")
          .eq(photoColumn, id)
        if (photosError) throw photosError

        // 4. Combine all into logData
        setLogData({ ...log, parts: parts || [], photos: photos || [] })
        setLoading(false)
      } catch (error: any) {
        console.error("Error fetching log for edit:", error)
        toast({ title: "Error", description: error.message || "Could not load log.", variant: "destructive" })
        router.push("/logs")
      }
    }
    fetchLog()
  }, [id, type, supabase, toast, userId, router])

  if (loading) {
    return <div className="text-center py-8">Loading log details…</div>
  }

  return (
    <LogForm
      userId={userId}
      type={type}
      assetId={logData.asset_id}
      defaultPublic={logData.is_public ?? true}
      logData={logData}
      editMode={true}
    />
  )
}
