import { redirect } from "next/navigation"
import { getSession } from "@/lib/supabase-server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { LogEditForm } from "./log-edit-form"

export default async function EditLogPage({
  searchParams,
}: {
  searchParams: { id?: string; type?: string }
}) {
  // Require auth
  const session = await getSession()
  if (!session) redirect("/login")

  const id = searchParams.id
  const type = searchParams.type as "repair" | "maintenance"
  if (!id || !type) {
    // Missing params, redirect back
    redirect("/logs")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <LogEditForm userId={session.user.id} id={id} type={type} />
      </main>
      <Footer />
    </div>
  )
}
