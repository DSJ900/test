"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { X, Plus } from "lucide-react"
import { formatCurrency } from "@/lib/utils"
import { formatVehicleData, capitalizeFirst } from "@/lib/format-utils"

type Asset = {
  id: string
  name: string
  make: string
  model: string
  year: number
  engine: string
  transmission: string
}

type Part = {
  id: string
  part_number: string
  name: string
  price: number | null
}

type LogFormProps = {
  userId: string
  type: "repair" | "maintenance"
  assetId?: string
  defaultPublic: boolean
  logData?: any
  editMode?: boolean
}

export function LogForm({
  userId,
  type: initialType,
  assetId,
  defaultPublic,
  logData,
  editMode = false,
}: LogFormProps) {
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [assets, setAssets] = useState<Asset[]>([])
  const [type, setType] = useState<"repair" | "maintenance">(initialType)
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null)
  const [parts, setParts] = useState<Part[]>([{ id: crypto.randomUUID(), part_number: "", name: "", price: null }])
  const [photos, setPhotos] = useState<File[]>([])
  const [photoUrls, setPhotoUrls] = useState<string[]>([])

  const [formData, setFormData] = useState({
    asset_id: assetId || "",
    make: "",
    model: "",
    year: new Date().getFullYear(),
    engine: "",
    transmission: "",
    issue_description: "",
    cause: "",
    repair_notes: "",
    tools_used: "",
    miles_hours: "",
    maintenance_type: "",
    description: "",
    is_public: false,
  })

  useEffect(() => {
    fetchAssets()
  }, [])

  useEffect(() => {
    if (assetId) {
      const asset = assets.find((a) => a.id === assetId)
      if (asset) {
        setSelectedAsset(asset)
        setFormData((prev) => ({
          ...prev,
          asset_id: asset.id,
          make: asset.make,
          model: asset.model,
          year: asset.year,
          engine: asset.engine,
          transmission: asset.transmission,
        }))
      }
    }
  }, [assetId, assets])

  // Populate form data when editing
  useEffect(() => {
    if (editMode && logData) {
      setFormData({
        asset_id: logData.asset_id || "",
        make: logData.make || "",
        model: logData.model || "",
        year: logData.year || new Date().getFullYear(),
        engine: logData.engine || "",
        transmission: logData.transmission || "",
        issue_description: logData.issue_description || "",
        cause: logData.cause || "",
        repair_notes: logData.repair_notes || "",
        tools_used: logData.tools_used || "",
        miles_hours: logData.miles_hours?.toString() || "",
        maintenance_type: logData.maintenance_type || "",
        description: logData.description || "",
        is_public: logData.is_public !== undefined ? logData.is_public : type === "repair" ? defaultPublic : false,
      })

      // Set parts if they exist
      if (logData.parts && logData.parts.length > 0) {
        setParts(
          logData.parts.map((part: any) => ({
            id: part.id || crypto.randomUUID(),
            part_number: part.part_number || "",
            name: part.name || "",
            price: part.price || null,
          })),
        )
      }

      // Set existing photos if they exist
      if (logData.photos && logData.photos.length > 0) {
        const existingPhotoUrls = logData.photos.map((photo: any) => photo.url)
        setPhotoUrls(existingPhotoUrls)
      }
    }
  }, [editMode, logData, type, defaultPublic])

  // Set initial is_public state based on type and defaultPublic (for new logs only)
  useEffect(() => {
    if (!editMode) {
      setFormData((prev) => ({
        ...prev,
        is_public: type === "repair" ? defaultPublic : false,
      }))
    }
  }, [type, defaultPublic, editMode])

  async function fetchAssets() {
    try {
      const { data, error } = await supabase.from("assets").select("*").order("name")

      if (error) throw error
      setAssets(data || [])
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to fetch assets.",
        variant: "destructive",
      })
    }
  }

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  function handleAssetChange(value: string) {
    if (!value) {
      setSelectedAsset(null)
      setFormData((prev) => ({
        ...prev,
        asset_id: "",
        make: "",
        model: "",
        year: new Date().getFullYear(),
        engine: "",
        transmission: "",
      }))
      return
    }

    const asset = assets.find((a) => a.id === value)
    if (asset) {
      setSelectedAsset(asset)
      setFormData((prev) => ({
        ...prev,
        asset_id: asset.id,
        make: asset.make,
        model: asset.model,
        year: asset.year,
        engine: asset.engine,
        transmission: asset.transmission,
      }))
    }
  }

  function handlePartChange(id: string, field: keyof Part, value: string) {
    setParts((prev) =>
      prev.map((part) =>
        part.id === id
          ? {
              ...part,
              [field]: field === "price" ? (value ? Number.parseFloat(value) : null) : value,
            }
          : part,
      ),
    )
  }

  function addPart() {
    setParts((prev) => [...prev, { id: crypto.randomUUID(), part_number: "", name: "", price: null }])
  }

  function removePart(id: string) {
    setParts((prev) => prev.filter((part) => part.id !== id))
  }

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files && e.target.files.length > 0) {
      const newPhotos = Array.from(e.target.files)
      const totalPhotos = photos.length + newPhotos.length

      if (totalPhotos > 5) {
        toast({
          title: "Photo Limit Exceeded",
          description: "You can upload a maximum of 5 photos per log.",
          variant: "destructive",
        })
        return
      }

      setPhotos((prev) => [...prev, ...newPhotos])

      // Create object URLs for preview
      const newUrls = newPhotos.map((file) => URL.createObjectURL(file))
      setPhotoUrls((prev) => [...prev, ...newUrls])
    }
  }

  function removePhoto(index: number) {
    setPhotos((prev) => prev.filter((_, i) => i !== index))

    // Revoke the object URL to avoid memory leaks
    URL.revokeObjectURL(photoUrls[index])
    setPhotoUrls((prev) => prev.filter((_, i) => i !== index))
  }

  async function uploadPhotos(logId: string, logType: "repair" | "maintenance") {
    const uploadPromises = photos.map(async (file) => {
      const fileExt = file.name.split(".").pop()
      const fileName = `${crypto.randomUUID()}.${fileExt}`
      const filePath = `${userId}/${logType}/${logId}/${fileName}`

      const { error: uploadError } = await supabase.storage.from("photos").upload(filePath, file)

      if (uploadError) throw uploadError

      const { data } = supabase.storage.from("photos").getPublicUrl(filePath)

      return {
        log_id: logId,
        log_type: logType,
        url: data.publicUrl,
      }
    })

    return Promise.all(uploadPromises)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)

    try {
      // Calculate total cost from parts
      const totalCost = parts.reduce((sum, part) => sum + (part.price || 0), 0)

      let logId = editMode ? logData.id : null

      let reference_id: string |null = null
      if (!editMode) {
        const response = await fetch("/api/generate-reference-id")
        if (!response.ok) throw new Error("Failed to generate reference ID")
          const { referenceId } = await response.json()
        reference_id = referenceId
      }

      if (type === "repair") {
        // Prepare repair data
        const vehicleData = {
          make: formData.make,
          model: formData.model,
          year: Number.parseInt(formData.year.toString()),
          engine: formData.engine,
          transmission: formData.transmission,
        }

        const formattedVehicleData = formatVehicleData(vehicleData)

        const repairData = {
          user_id: userId,
          asset_id: formData.asset_id || null,
          ...formattedVehicleData,
          issue_description: capitalizeFirst(formData.issue_description),
          cause: capitalizeFirst(formData.cause),
          repair_notes: formData.repair_notes || null,
          tools_used: formData.tools_used || null,
          miles_hours: formData.miles_hours ? Number.parseFloat(formData.miles_hours) : null,
          total_cost: totalCost > 0 ? totalCost : null,
          is_public: formData.is_public,
        }

        if (editMode) {
          // Update existing repair log
          const { error: repairError } = await supabase
            .from("repair_logs")
            .update(repairData)
            .eq("id", logId)
            .eq("user_id", userId)

          if (repairError) throw repairError
        } else {
          // Insert new repair log
          
          const { data: newRepairData, error: repairError } = await supabase
            .from("repair_logs")
            .insert([{ ...repairData, reference_id }])
            .select()

          if (repairError) throw repairError
          logId = newRepairData[0].id
        }
      } else {
        // Prepare maintenance data
        const maintenanceData = {
          user_id: userId,
          asset_id: formData.asset_id,
          maintenance_type: capitalizeFirst(formData.maintenance_type),
          description: formData.description || null,
          miles_hours: Number.parseFloat(formData.miles_hours),
          total_cost: totalCost > 0 ? totalCost : null,
        }

        if (editMode) {
          // Update existing maintenance log
          const { error: maintenanceError } = await supabase
            .from("maintenance_logs")
            .update(maintenanceData)
            .eq("id", logId)
            .eq("user_id", userId)

          if (maintenanceError) throw maintenanceError
        } else {
          // Insert new maintenance log
          const { data: newMaintenanceData, error: maintenanceError } = await supabase
            .from("maintenance_logs")
            .insert([{ ...maintenanceData, reference_id }])
            .select()

          if (maintenanceError) throw maintenanceError
          logId = newMaintenanceData[0].id
        }
      }

      // Handle parts - delete existing and insert new ones if editing
      const validParts = parts.filter((part) => part.name.trim() !== "")

      if (editMode) {
        // Delete existing parts
        const partsTable = type === "repair" ? "repair_parts" : "maintenance_parts"
        const partsColumn = type === "repair" ? "repair_log_id" : "maintenance_log_id"

        const { error: deletePartsError } = await supabase.from(partsTable).delete().eq(partsColumn, logId)

        if (deletePartsError) throw deletePartsError
      }

      // Insert new parts
      if (validParts.length > 0) {
        const partsTable = type === "repair" ? "repair_parts" : "maintenance_parts"
        const partsColumn = type === "repair" ? "repair_log_id" : "maintenance_log_id"

        const { error: partsError } = await supabase.from(partsTable).insert(
          validParts.map((part) => ({
            [partsColumn]: logId,
            part_number: part.part_number || null,
            name: part.name,
            price: part.price,
          })),
        )

        if (partsError) throw partsError
      }

      // Handle photos - only upload new photos (File objects)
      const newPhotos = photos.filter((photo) => photo instanceof File)
      if (newPhotos.length > 0) {
        const photoData = await uploadPhotos(logId, type)
        const photoTable = type === "repair" ? "repair_photos" : "maintenance_photos"
        const photoColumn = type === "repair" ? "repair_log_id" : "maintenance_log_id"

        const { error: photosError } = await supabase.from(photoTable).insert(
          photoData.map((photo) => ({
            [photoColumn]: logId,
            url: photo.url,
          })),
        )

        if (photosError) throw photosError
      }

      toast({
        title: "Success",
        description: `${type === "repair" ? "Repair" : "Maintenance"} log ${editMode ? "updated" : "created"} successfully.`,
      })

      router.push("/logs")
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || `Failed to ${editMode ? "update" : "create"} ${type} log.`,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">
          {editMode
            ? `Edit ${type === "repair" ? "Repair" : "Maintenance"} Log`
            : `Log ${type === "repair" ? "a Repair" : "Routine Maintenance"}`}
        </h1>
        <p className="text-gray-500">
          {type === "repair" ? "Document a repair with detailed information" : "Keep track of routine maintenance"}
        </p>
      </div>

      <Tabs value={type} onValueChange={(value) => setType(value as "repair" | "maintenance")}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="repair">Repair</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
        </TabsList>
      </Tabs>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Vehicle Information</CardTitle>
            <CardDescription>
              {type === "repair"
                ? "Select a vehicle from your garage or enter details manually"
                : "Select a vehicle from your garage"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="asset_id">Select Vehicle</Label>
              <Select
                value={formData.asset_id}
                onValueChange={handleAssetChange}
                disabled={type === "maintenance" && assets.length === 0}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a vehicle" />
                </SelectTrigger>
                <SelectContent>
                  {type === "repair" && <SelectItem value="manual">Enter manually</SelectItem>}
                  {assets.map((asset) => (
                    <SelectItem key={asset.id} value={asset.id}>
                      {asset.name} ({asset.year} {asset.make} {asset.model})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {type === "maintenance" && assets.length === 0 && (
                <p className="text-sm text-red-500">
                  You need to add a vehicle to your garage first to log maintenance.{" "}
                  <Button variant="link" className="h-auto p-0 text-sm" onClick={() => router.push("/dashboard")}>
                    Add a vehicle
                  </Button>
                </p>
              )}
            </div>

            {type === "repair" && !formData.asset_id && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="make">Make</Label>
                  <Input id="make" name="make" value={formData.make} onChange={handleInputChange} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="model">Model</Label>
                  <Input id="model" name="model" value={formData.model} onChange={handleInputChange} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="year">Year</Label>
                  <Input
                    id="year"
                    name="year"
                    type="number"
                    value={formData.year}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="engine">Engine</Label>
                  <Input id="engine" name="engine" value={formData.engine} onChange={handleInputChange} required />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="transmission">Transmission</Label>
                  <Input
                    id="transmission"
                    name="transmission"
                    value={formData.transmission}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="h-6" />

        <Card>
          <CardHeader>
            <CardTitle>{type === "repair" ? "Repair Details" : "Maintenance Details"}</CardTitle>
            <CardDescription>
              {type === "repair"
                ? "Provide information about the repair"
                : "Provide information about the maintenance performed"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {type === "repair" ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="issue_description">Description of Issue</Label>
                  <Input
                    id="issue_description"
                    name="issue_description"
                    value={formData.issue_description}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cause">Cause of Issue</Label>
                  <Input id="cause" name="cause" value={formData.cause} onChange={handleInputChange} required />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="miles_hours">Miles/Hours (Optional)</Label>
                    <Input
                      id="miles_hours"
                      name="miles_hours"
                      type="number"
                      value={formData.miles_hours}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="repair_notes">Repair Notes (Optional)</Label>
                  <Textarea
                    id="repair_notes"
                    name="repair_notes"
                    value={formData.repair_notes}
                    onChange={handleInputChange}
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tools_used">Tools Used (Optional)</Label>
                  <Textarea
                    id="tools_used"
                    name="tools_used"
                    value={formData.tools_used}
                    onChange={handleInputChange}
                    rows={2}
                  />
                </div>
              </>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="maintenance_type">Maintenance Performed</Label>
                  <Input
                    id="maintenance_type"
                    name="maintenance_type"
                    value={formData.maintenance_type}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="miles_hours">Miles/Hours</Label>
                  <Input
                    id="miles_hours"
                    name="miles_hours"
                    type="number"
                    value={formData.miles_hours}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={3}
                  />
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <div className="h-6" />

        <Card>
          <CardHeader>
            <CardTitle>Parts Used</CardTitle>
            <CardDescription>
              List the parts used in this {type === "repair" ? "repair" : "maintenance"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {parts.map((part, index) => (
              <div key={part.id} className="flex items-end gap-2">
                <div className="flex-1 space-y-2">
                  <Label htmlFor={`part-number-${index}`}>Part Number</Label>
                  <Input
                    id={`part-number-${index}`}
                    value={part.part_number}
                    onChange={(e) => handlePartChange(part.id, "part_number", e.target.value)}
                    placeholder="Optional"
                  />
                </div>
                <div className="flex-[2] space-y-2">
                  <Label htmlFor={`part-name-${index}`}>Part Name</Label>
                  <Input
                    id={`part-name-${index}`}
                    value={part.name}
                    onChange={(e) => handlePartChange(part.id, "name", e.target.value)}
                    placeholder="Required for valid parts"
                  />
                </div>
                <div className="flex-1 space-y-2">
                  <Label htmlFor={`part-price-${index}`}>Price</Label>
                  <Input
                    id={`part-price-${index}`}
                    type="number"
                    step="0.01"
                    value={part.price === null ? "" : part.price}
                    onChange={(e) => handlePartChange(part.id, "price", e.target.value)}
                    placeholder="Optional"
                  />
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removePart(part.id)}
                  disabled={parts.length === 1}
                >
                  <X className="h-4 w-4" />
                  <span className="sr-only">Remove</span>
                </Button>
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" onClick={addPart} className="mt-2">
              <Plus className="mr-2 h-4 w-4" /> Add Part
            </Button>

            <div className="pt-4 border-t">
              <div className="flex justify-between">
                <span className="font-medium">Total Cost:</span>
                <span>{formatCurrency(parts.reduce((sum, part) => sum + (part.price || 0), 0))}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="h-6" />

        <Card>
          <CardHeader>
            <CardTitle>Photos</CardTitle>
            <CardDescription>
              Attach photos related to this {type === "repair" ? "repair" : "maintenance"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="photos">Upload Photos (Maximum 5)</Label>
              <Input id="photos" type="file" accept="image/*" multiple onChange={handlePhotoChange} />
              <p className="text-xs text-gray-500">You can upload up to 5 photos. Current: {photos.length}/5</p>
            </div>

            {photoUrls.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {photoUrls.map((url, index) => (
                  <div key={index} className="relative">
                    <img
                      src={url || "/placeholder.svg"}
                      alt={`Photo ${index + 1}`}
                      className="w-full h-32 object-cover rounded-lg"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2 h-6 w-6"
                      onClick={() => removePhoto(index)}
                    >
                      <X className="h-3 w-3" />
                      <span className="sr-only">Remove photo</span>
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {type === "repair" && (
          <>
            <div className="h-6" />
            <Card>
              <CardHeader>
                <CardTitle>Visibility</CardTitle>
                <CardDescription>Choose whether this repair should be visible to the public</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="is_public"
                    checked={formData.is_public}
                    onChange={(e) => setFormData((prev) => ({ ...prev, is_public: e.target.checked }))}
                    className="rounded border-gray-300"
                  />
                  <Label htmlFor="is_public">Make this repair public (others can view and learn from it)</Label>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        <div className="h-6" />

        <div className="flex justify-end gap-4">
          <Button type="button" variant="outline" onClick={() => router.push("/logs")}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading || (type === "maintenance" && !formData.asset_id)}>
            {loading
              ? editMode
                ? "Updating..."
                : "Saving..."
              : editMode
                ? `Update ${type === "repair" ? "Repair" : "Maintenance"}`
                : `Save ${type === "repair" ? "Repair" : "Maintenance"}`}
          </Button>
        </div>
      </form>
    </div>
  )
}
