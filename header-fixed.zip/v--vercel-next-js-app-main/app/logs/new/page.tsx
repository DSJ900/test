import { redirect } from "next/navigation"
import { getSession, getUserDetails } from "@/lib/supabase-server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { LogForm } from "./log-form"

export default async function NewLogPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  const userDetails = await getUserDetails()
  const type = (searchParams.type as string) || "repair"
  const assetId = (searchParams.asset as string) || undefined

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <LogForm
          userId={session.user.id}
          type={type as "repair" | "maintenance"}
          assetId={assetId}
          defaultPublic={userDetails?.default_public ?? false}
        />
      </main>
      <Footer />
    </div>
  )
}
