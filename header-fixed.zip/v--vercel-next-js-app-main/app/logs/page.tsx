import { redirect } from "next/navigation"
import { getSession } from "@/lib/supabase-server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { LogsContent } from "./logs-content"

export default async function LogsPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <LogsContent userId={session.user.id} />
      </main>
      <Footer />
    </div>
  )
}
