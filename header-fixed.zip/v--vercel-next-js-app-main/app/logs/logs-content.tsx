"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { formatCurrency, formatDate } from "@/lib/utils"
import { Eye, EyeOff, Pencil, Trash2, Wrench, PenToolIcon as Tool, Search, FileText, Printer } from "lucide-react"
import Link from "next/link"

type RepairLog = {
  id: string
  created_at: string
  asset_id: string | null
  make: string
  model: string
  year: number
  issue_description: string
  cause: string
  total_cost: number | null
  is_public: boolean
  asset?: {
    name: string
  }
  reference_id?: string
}

type MaintenanceLog = {
  id: string
  created_at: string
  asset_id: string
  maintenance_type: string
  miles_hours: number
  total_cost: number | null
  asset: {
    name: string
    make: string
    model: string
    year: number
  }
  reference_id?: string
}

type LogsContentProps = {
  userId: string
}

export function LogsContent({ userId }: LogsContentProps) {
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [repairLogs, setRepairLogs] = useState<RepairLog[]>([])
  const [maintenanceLogs, setMaintenanceLogs] = useState<MaintenanceLog[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false)
  const [currentLog, setCurrentLog] = useState<{ id: string; type: "repair" | "maintenance" } | null>(null)

  useEffect(() => {
    fetchLogs()
  }, [])

  async function fetchLogs() {
    setLoading(true)
    try {
      // Fetch repair logs
      const { data: repairData, error: repairError } = await supabase
        .from("repair_logs")
        .select("*, asset:assets(name), reference_id")
        .order("created_at", { ascending: false })

      if (repairError) throw repairError

      // Fetch maintenance logs
      const { data: maintenanceData, error: maintenanceError } = await supabase
        .from("maintenance_logs")
        .select("*, asset:assets(name, make, model, year), reference_id")
        .order("created_at", { ascending: false })

      if (maintenanceError) throw maintenanceError

      setRepairLogs(repairData || [])
      setMaintenanceLogs(maintenanceData || [])
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to fetch logs.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  async function toggleRepairVisibility(log: RepairLog) {
    try {
      const { error } = await supabase.from("repair_logs").update({ is_public: !log.is_public }).eq("id", log.id)

      if (error) throw error

      setRepairLogs((prev) => prev.map((item) => (item.id === log.id ? { ...item, is_public: !log.is_public } : item)))

      toast({
        title: "Success",
        description: `Repair log is now ${!log.is_public ? "public" : "private"}.`,
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update visibility.",
        variant: "destructive",
      })
    }
  }

  function openDeleteModal(id: string, type: "repair" | "maintenance") {
    setCurrentLog({ id, type })
    setShowDeleteConfirmModal(true)
  }

  async function handleDeleteLog() {
    if (!currentLog) return

    try {
      const { error } = await supabase
        .from(currentLog.type === "repair" ? "repair_logs" : "maintenance_logs")
        .delete()
        .eq("id", currentLog.id)

      if (error) throw error

      toast({
        title: "Success",
        description: "Log deleted successfully.",
      })

      if (currentLog.type === "repair") {
        setRepairLogs((prev) => prev.filter((log) => log.id !== currentLog.id))
      } else {
        setMaintenanceLogs((prev) => prev.filter((log) => log.id !== currentLog.id))
      }

      setShowDeleteConfirmModal(false)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete log.",
        variant: "destructive",
      })
    }
  }

  const filteredRepairLogs = repairLogs.filter((log) => {
    const searchTermLower = searchTerm.toLowerCase()
    return (
      log.make.toLowerCase().includes(searchTermLower) ||
      log.model.toLowerCase().includes(searchTermLower) ||
      log.issue_description.toLowerCase().includes(searchTermLower) ||
      log.cause.toLowerCase().includes(searchTermLower) ||
      (log.asset?.name && log.asset.name.toLowerCase().includes(searchTermLower)) ||
      (log.reference_id && log.reference_id.toLocaleLowerCase().includes(searchTermLower))
    )
  })

  const filteredMaintenanceLogs = maintenanceLogs.filter((log) => {
    const searchTermLower = searchTerm.toLowerCase()
    return (
      log.maintenance_type.toLowerCase().includes(searchTermLower) ||
      log.asset.name.toLowerCase().includes(searchTermLower) ||
      log.asset.make.toLowerCase().includes(searchTermLower) ||
      log.asset.model.toLowerCase().includes(searchTermLower) ||
      (log.reference_id && log.reference_id.toLocaleLowerCase().includes(searchTermLower))
    )
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Logs</h1>
          <p className="text-gray-500">View and manage your repair and maintenance logs</p>
        </div>
        <Link href="/logs/new">
          <Button>
            <Wrench className="mr-2 h-4 w-4" /> Log New Repair or Maintenance
          </Button>
        </Link>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
        <Input
          placeholder="Search logs..."
          className="pl-10"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <Tabs defaultValue="repairs">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="repairs">Repairs</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
        </TabsList>
        <TabsContent value="repairs" className="mt-6">
          {loading ? (
            <div className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader className="bg-gray-100 h-16" />
                  <CardContent className="py-4">
                    <div className="h-4 bg-gray-100 rounded mb-2" />
                    <div className="h-4 bg-gray-100 rounded w-2/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredRepairLogs.length > 0 ? (
            <div className="space-y-4">
              {filteredRepairLogs.map((log) => (
                <Card key={log.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{log.issue_description}</CardTitle>
                        <CardDescription>
                          {log.year} {log.make} {log.model}
                          {log.asset?.name && ` - ${log.asset.name}`}
                        </CardDescription>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleRepairVisibility(log)}
                          title={log.is_public ? "Make Private" : "Make Public"}
                        >
                          {log.is_public ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                          <span className="sr-only">{log.is_public ? "Make Private" : "Make Public"}</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => router.push(`/logs/view?id=${log.id}&type=repair`)}
                        >
                          <Pencil className="h-4 w-4" />
                          <span className="sr-only">Edit</span>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => openDeleteModal(log.id, "repair")}>
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="text-sm space-y-1">
                      {log.reference_id && (
                        <p>
                          <span className="font-medium">Ref ID:</span>{" "}
                          <span className="text-blue-600 font-mono">{log.reference_id}</span>
                        </p>
                      )}
                      <p>
                        <span className="font-medium">Cause:</span> {log.cause}
                      </p>
                      {log.total_cost !== null && (
                        <p>
                          <span className="font-medium">Cost:</span> {formatCurrency(log.total_cost)}
                        </p>
                      )}
                      <p>
                        <span className="font-medium">Date:</span> {formatDate(log.created_at)}
                      </p>
                      <p>
                        <span className="font-medium">Visibility:</span>{" "}
                        <span className={log.is_public ? "text-green-600" : "text-gray-600"}>
                          {log.is_public ? "Public" : "Private"}
                        </span>
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <div className="flex gap-2">
                      <Link href={`/logs/view?id=${log.id}&type=repair`}>
                        <Button variant="outline" size="sm">
                          <FileText className="mr-2 h-4 w-4" /> View Details
                        </Button>
                      </Link>
                      <Button variant="ghost" size="sm" onClick={() => window.print()}>
                        <Printer className="mr-2 h-4 w-4" /> Print
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Wrench className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium mb-2">No Repair Logs Found</h3>
                <p className="text-gray-500 text-center mb-4">
                  {searchTerm
                    ? "No repair logs match your search. Try a different term."
                    : "You haven't logged any repairs yet."}
                </p>
                {!searchTerm && (
                  <Link href="/logs/new?type=repair">
                    <Button>Log a Repair</Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>
        <TabsContent value="maintenance" className="mt-6">
          {loading ? (
            <div className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader className="bg-gray-100 h-16" />
                  <CardContent className="py-4">
                    <div className="h-4 bg-gray-100 rounded mb-2" />
                    <div className="h-4 bg-gray-100 rounded w-2/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredMaintenanceLogs.length > 0 ? (
            <div className="space-y-4">
              {filteredMaintenanceLogs.map((log) => (
                <Card key={log.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{log.maintenance_type}</CardTitle>
                        <CardDescription>
                          {log.asset.year} {log.asset.make} {log.asset.model} - {log.asset.name}
                        </CardDescription>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => router.push(`/logs/view?id=${log.id}&type=maintenance`)}
                        >
                          <Pencil className="h-4 w-4" />
                          <span className="sr-only">Edit</span>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => openDeleteModal(log.id, "maintenance")}>
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="text-sm">
                      <p>
                        <span className="font-medium">Miles/Hours:</span> {log.miles_hours.toLocaleString()}
                      </p>

                      {log.reference_id && (
                        <p>
                          <span className="font-medium">Ref ID:</span> {log.reference_id}
                        </p>
                      )}
                      {log.total_cost !== null && (
                        <p>
                          <span className="font-medium">Cost:</span> {formatCurrency(log.total_cost)}
                        </p>
                      )}
                      <p>
                        <span className="font-medium">Date:</span> {formatDate(log.created_at)}
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <div className="flex gap-2">
                      <Link href={`/logs/view?id=${log.id}&type=maintenance`}>
                        <Button variant="outline" size="sm">
                          <FileText className="mr-2 h-4 w-4" /> View Details
                        </Button>
                      </Link>
                      <Button variant="ghost" size="sm" onClick={() => window.print()}>
                        <Printer className="mr-2 h-4 w-4" /> Print
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Tool className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium mb-2">No Maintenance Logs Found</h3>
                <p className="text-gray-500 text-center mb-4">
                  {searchTerm
                    ? "No maintenance logs match your search. Try a different term."
                    : "You haven't logged any maintenance yet."}
                </p>
                {!searchTerm && (
                  <Link href="/logs/new?type=maintenance">
                    <Button>Log Maintenance</Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Delete Confirmation Modal */}
      <Dialog open={showDeleteConfirmModal} onOpenChange={setShowDeleteConfirmModal}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this {currentLog?.type} log? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteConfirmModal(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteLog}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
