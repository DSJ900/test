import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function PrivacyPolicyPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Privacy Policy</h1>
            <p className="text-gray-500">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          <div className="prose prose-gray max-w-none">
            <h2>1. Introduction</h2>
            <p>
              WrenchLoop ("we", "us", or "our") is committed to protecting your privacy. This Privacy Policy explains how
              we collect, use, and share your information when you use our website and services.
            </p>

            <h2>2. Information We Collect</h2>
            <ul>
              <li><strong>Account Information:</strong> Name, email address, password, and optional company name.</li>
              <li><strong>Repair Data:</strong> Logs, asset information, photos, comments, and other repair-related content.</li>
              <li><strong>Usage Data:</strong> IP address, browser type, device info, and interaction with our platform.</li>
              <li><strong>Payment Info:</strong> Billing details collected via our secure payment processor (we do not store credit card numbers).</li>
            </ul>

            <h2>3. How We Use Your Information</h2>
            <p>We use your information to:</p>
            <ul>
              <li>Provide and maintain the WrenchLoop service</li>
              <li>Communicate with you about your account</li>
              <li>Improve our platform and user experience</li>
              <li>Prevent fraud and abuse</li>
              <li>Send transactional and promotional emails (you can opt out)</li>
            </ul>

            <h2>4. Sharing Your Information</h2>
            <p>We do not sell your personal information. We may share it with:</p>
            <ul>
              <li>Trusted service providers (e.g. email and hosting platforms)</li>
              <li>Legal authorities if required by law</li>
              <li>Other users if you choose to make content public</li>
            </ul>

            <h2>5. Cookies & Tracking</h2>
            <p>
              We use cookies and similar technologies to personalize your experience and analyze usage. You can control
              cookies through your browser settings.
            </p>

            <h2>6. Data Retention</h2>
            <p>
              We retain your data as long as your account is active or as needed to provide services. Public logs and posts
              may remain visible after account deletion unless you request removal.
            </p>

            <h2>7. Your Rights</h2>
            <p>You have the right to:</p>
            <ul>
              <li>Access the data we hold about you</li>
              <li>Request correction or deletion of your data</li>
              <li>Withdraw consent at any time</li>
            </ul>
            <p>
              To make a request, email <a href="mailto:support@wrenchloop.com">support@wrenchloop.com</a>.
            </p>

            <h2>8. Children’s Privacy</h2>
            <p>WrenchLoop is not intended for children under 13. We do not knowingly collect personal information from children.</p>

            <h2>9. Security</h2>
            <p>
              We implement reasonable safeguards to protect your data, but no system is 100% secure. You use the service at
              your own risk.
            </p>

            <h2>10. Changes to This Policy</h2>
            <p>
              We may update this policy from time to time. Continued use of WrenchLoop after changes means you accept the
              new terms.
            </p>

            <h2>11. Contact Us</h2>
            <p>
              If you have questions about this Privacy Policy, contact us at <a href="mailto:support@wrenchloop.com">support@wrenchloop.com</a>.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}