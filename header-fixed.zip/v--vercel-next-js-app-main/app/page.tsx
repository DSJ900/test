import { redirect } from "next/navigation"
import { getSession } from "@/lib/supabase-server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import LandingPageClient from "@/components/landing-page-client"

export const metadata = {
  title: "WrenchLoop – Repair Logs Made Simple",
  description: "Track vehicle and equipment repairs. Share repair history. Simplify maintenance. WrenchLoop is your digital garage.",
  keywords: ["vehicle maintenance", "repair log", "fleet tracking", "car repairs", "WrenchLoop", "equipment maintenance"],
  openGraph: {
    title: "WrenchLoop – Repair Logs Made Simple",
    description: "Track repairs. Share knowledge. Stay in the loop.",
    url: "https://wrenchloop.com",
    siteName: "WrenchLoop",
    images: [
      {
        url: "https://wrenchloop.com/og-image.png",
        width: 1200,
        height: 630,
        alt: "WrenchLoop App Screenshot",
      },
    ],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "WrenchLoop – Repair Logs Made Simple",
    description: "Track repairs. Share knowledge. Stay in the loop.",
    images: ["https://wrenchloop.com/og-image.png"],
  },
}

export default async function LandingPage() {
  const session = await getSession()
  if (session) redirect("/dashboard")

  return (
    <div className="flex flex-col min-h-screen bg-white text-black">
      <Header transparent />
      <LandingPageClient />
      <Footer />
    </div>
  )
}
