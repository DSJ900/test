"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
interface Plan {
  name: string
  description: string
  price: number
  features: string[]
  priceId: string
  maxAssets: number
}

interface Props {
  plans: Record<string, Plan>
}
import { Check, Zap, Crown, Star } from "lucide-react"
import { loadStripe } from "@stripe/stripe-js"

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

export function PricingContent({ plans }: Props) {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [user, setUser] = useState<any>(null)
  const [userDetails, setUserDetails] = useState<any>(null)
  const [loading, setLoading] = useState<string | null>(null)

  useEffect(() => {
    checkUser()
  }, [])

  async function checkUser() {
    const { data } = await supabase.auth.getUser()
    setUser(data.user)

    if (data.user) {
      const { data: profile } = await supabase.from("profiles").select("*").eq("id", data.user.id).single()
      setUserDetails(profile)
    }
  }

  async function handleSubscribe(planKey: string) {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to subscribe to a plan.",
        variant: "destructive",
      })
      return
    }

    if (planKey === "free" && userDetails?.subscription_tier === "free") {
  toast({
    title: "Already on free plan",
    description: "You're already on the free plan.",
  })
  return
}

if (planKey === "free" && userDetails?.subscription_tier !== "free") {
  // Call your backend API to cancel their Stripe subscription
  try {
    const response = await fetch("/api/cancel-subscription", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ userId: user.id }),
    })

    const { error } = await response.json()

    if (error) throw new Error(error)

    toast({
      title: "Downgraded to Free",
      description: "Your subscription has been canceled and downgraded.",
    })

    await checkUser() // refresh UI
  } catch (err: any) {
    toast({
      title: "Error",
      description: err.message || "Failed to cancel subscription.",
      variant: "destructive",
    })
  }

  return
}

    setLoading(planKey)

    try {
      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          priceId: plans[planKey as keyof typeof PLANS].priceId,
          userId: user.id,
        }),
      })

      const { sessionId, error } = await response.json()

      if (error) {
        throw new Error(error)
      }

      const stripe = await stripePromise
      if (stripe) {
        const { error } = await stripe.redirectToCheckout({ sessionId })
        if (error) {
          throw error
        }
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to start checkout process.",
        variant: "destructive",
      })
    } finally {
      setLoading(null)
    }
  }

  function getPlanIcon(planKey: string) {
    switch (planKey) {
      case "free":
        return <Star className="h-6 w-6" />
      case "small":
        return <Zap className="h-6 w-6" />
      case "large":
        return <Crown className="h-6 w-6" />
      default:
        return <Star className="h-6 w-6" />
    }
  }

  function getPlanColor(planKey: string) {
    switch (planKey) {
      case "free":
        return "text-gray-600"
      case "small":
        return "text-blue-600"
      case "large":
        return "text-purple-600"
      default:
        return "text-gray-600"
    }
  }

  function isCurrentPlan(planKey: string) {
    if (!userDetails) return false
    return userDetails.subscription_tier === planKey
  }

  function getButtonText(planKey: string) {
    if (!user) return "Sign Up to Subscribe"
    if (isCurrentPlan(planKey)) return "Current Plan"
    if (planKey === "free") return "Downgrade to Free"
    return `Subscribe to ${plans[planKey as keyof typeof plans].name}`
  }

  return (
    <div className="py-12">
      <div className="mx-auto w-full max-w-screen-xl px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Choose Your Plan</h1>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Select the perfect plan for your fleet size and needs. All plans include unlimited repair and maintenance
              logs.
            </p>
          </div>
        </div>

        <div className="mx-auto grid max-w-6xl items-start gap-6 py-12 lg:grid-cols-3 lg:gap-8">
          {Object.entries(plans).map(([planKey, plan]) => (
            <Card
              key={planKey}
              className={`relative ${planKey === "small" ? "border-blue-500 shadow-lg scale-105" : ""} ${
                isCurrentPlan(planKey) ? "ring-2 ring-green-500" : ""
              }`}
            >
              {planKey === "small" && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}
              {isCurrentPlan(planKey) && (
                <div className="absolute -top-3 right-4">
                  <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">Current</span>
                </div>
              )}
              <CardHeader className="text-center">
                <div className={`mx-auto mb-4 ${getPlanColor(planKey)}`}>{getPlanIcon(planKey)}</div>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  {plan.price > 0 && <span className="text-gray-500">/month</span>}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full"
                  variant={planKey === "small" ? "default" : "outline"}
                  onClick={() => handleSubscribe(planKey)}
                  disabled={loading === planKey || isCurrentPlan(planKey)}
                >
                  {loading === planKey ? "Processing..." : getButtonText(planKey)}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mx-auto max-w-4xl">
          <Card>
            <CardHeader>
              <CardTitle>Plan Comparison</CardTitle>
              <CardDescription>See what happens when you upgrade or downgrade your plan</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2">Feature</th>
                      <th className="text-center py-2">Free</th>
                      <th className="text-center py-2">Small Fleet</th>
                      <th className="text-center py-2">Large Fleet</th>
                    </tr>
                  </thead>
                  <tbody className="space-y-2">
                    <tr className="border-b">
                      <td className="py-2">Maximum Vehicles</td>
                      <td className="text-center py-2">5</td>
                      <td className="text-center py-2">20</td>
                      <td className="text-center py-2">150</td>
                    </tr>
                    {/* <tr className="border-b">
                      <td className="py-2">Employee Accounts</td>
                      <td className="text-center py-2">1</td>
                      <td className="text-center py-2">1</td>
                      <td className="text-center py-2">10</td>
                    </tr> */}
                    <tr className="border-b">
                      <td className="py-2">Repair & Maintenance Logs</td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2">Public Repair Library Access</td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2">Analytics Dashboard</td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2">Priority Support</td>
                      <td className="text-center py-2">-</td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                      <td className="text-center py-2">
                        <Check className="h-4 w-4 text-green-500 mx-auto" />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mx-auto max-w-2xl text-center mt-12">
          <h3 className="text-xl font-semibold mb-4">Frequently Asked Questions</h3>
          <div className="space-y-4 text-left">
            <div>
              <h4 className="font-medium">Can I change plans anytime?</h4>
              <p className="text-sm text-gray-600">
                Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately.
              </p>
            </div>
            <div>
              <h4 className="font-medium">What happens if I exceed my vehicle limit?</h4>
              <p className="text-sm text-gray-600">
                You'll be prompted to upgrade your plan when you try to add more vehicles than your current plan allows.
              </p>
            </div>
            <div>
              <h4 className="font-medium">Is there a free trial?</h4>
              <p className="text-sm text-gray-600">
                The free plan allows you to try WrenchLoop with up to 5 vehicles at no cost.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
