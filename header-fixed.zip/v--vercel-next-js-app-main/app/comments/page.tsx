import { createServerSupabaseClient } from "@/lib/supabase-server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { CommentsContent } from "./comments-content"
import { redirect } from "next/navigation"

export default async function CommentsPage() {
  const supabase = await createServerSupabaseClient()

  // Check if user is authenticated
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <CommentsContent />
      </main>
      <Footer />
    </div>
  )
}
