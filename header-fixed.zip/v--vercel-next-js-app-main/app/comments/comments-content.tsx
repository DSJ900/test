"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { formatDate } from "@/lib/utils"
import { MessageSquare, Eye, Trash2 } from "lucide-react"
import Link from "next/link"

type UserComment = {
  id: string
  content: string
  created_at: string
  repair_id: string
  repair_logs: {
    id: string
    make: string
    model: string
    year: number
    issue_description: string
  }
}

export function CommentsContent() {
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [comments, setComments] = useState<UserComment[]>([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    checkUser()
  }, [])

  async function checkUser() {
    const { data } = await supabase.auth.getUser()
    if (data.user) {
      setUser(data.user)
      fetchComments(data.user.id)
    } else {
      router.push("/login")
    }
  }

  async function fetchComments(userId: string) {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("comments")
        .select(`
          *,
          repair_logs!inner(
            id,
            make,
            model,
            year,
            issue_description
          )
        `)
        .eq("user_id", userId)
        .order("created_at", { ascending: false })

      if (error) throw error

      setComments(data || [])
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to fetch comments.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  async function deleteComment(commentId: string) {
    try {
      const { error } = await supabase.from("comments").delete().eq("id", commentId)

      if (error) throw error

      setComments(comments.filter((c) => c.id !== commentId))
      toast({
        title: "Success",
        description: "Comment deleted successfully.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete comment.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Comments</h1>
          <p className="text-gray-500">Your comments on repair guides</p>
        </div>
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="bg-gray-100 h-20" />
              <CardContent className="py-4">
                <div className="h-4 bg-gray-100 rounded mb-2" />
                <div className="h-4 bg-gray-100 rounded w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Comments</h1>
          <p className="text-gray-500">Your comments on repair guides ({comments.length})</p>
        </div>
      </div>

      {comments.length > 0 ? (
        <div className="space-y-4">
          {comments.map((comment) => (
            <Card key={comment.id}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">Comment on: {comment.repair_logs.issue_description}</CardTitle>
                    <CardDescription>
                      {comment.repair_logs.year} {comment.repair_logs.make} {comment.repair_logs.model}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">{formatDate(comment.created_at)}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-gray-700">{comment.content}</p>
                </div>
              </CardContent>
              <CardFooter>
                <div className="flex justify-between w-full">
                  <Link href={`/repairs/${comment.repair_logs.id}`}>
                    <Button variant="outline" size="sm">
                      <Eye className="mr-2 h-4 w-4" /> View Repair
                    </Button>
                  </Link>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteComment(comment.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="mr-2 h-4 w-4" /> Delete
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageSquare className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium mb-2">No Comments Yet</h3>
            <p className="text-gray-500 text-center mb-4">
              Start engaging with the community by commenting on repair guides.
            </p>
            <Link href="/repairs">
              <Button>Browse Repairs</Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
