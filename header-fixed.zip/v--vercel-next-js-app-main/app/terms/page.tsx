import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function TermsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Terms of Use</h1>
            <p className="text-gray-500">Last updated: June 23, 2025</p>
          </div>

          <div className="prose prose-gray max-w-none">
            <h2>1. Acceptance of Terms</h2>
            <p>
              By creating an account, accessing, or using WrenchLoop, you agree to be bound by these Terms of Use and any additional terms and policies referenced herein.
            </p>

            <h2>2. User Accounts</h2>
            <p>
              To access certain features of WrenchLoop, you must register for an account. You are responsible for maintaining the security of your account credentials and for all activity under your account. If you wish to delete your account, please contact support@wrenchloop.com. Even after account deletion, any public information you have posted (including repair logs, comments, and other user-generated content) will be archived and remain publicly viewable unless you specifically request its removal.
            </p>

            <h2>3. Privacy Policy</h2>
            <p>
              Your privacy is important to us. Please review our <a href="/privacy">Privacy Policy</a> to understand how we collect, use, and protect your information. By using WrenchLoop, you consent to our practices described in the Privacy Policy.
            </p>

            <h2>4. Refund Policy</h2>
            <p>
              All purchases of paid subscriptions are non-refundable except as required by law. If you experience any issues with billing or subscription, please contact us at support@wrenchloop.com.
            </p>

            <h2>5. Service Tiers</h2>
            <p>
              WrenchLoop offers both a free basic tier and paid commercial tiers starting at $5 per month.
            </p>

            <h2>6. User Content</h2>
            <p>
              You retain ownership of any content you submit to WrenchLoop. By submitting content, you grant WrenchLoop a worldwide, non-exclusive, royalty-free license to use, reproduce, adapt, publish, and distribute such content in connection with providing and promoting the service.
            </p>

            <h2>7. Prohibited Conduct</h2>
            <p>
              You agree not to use WrenchLoop for any unlawful purpose or to solicit others to perform unlawful acts. You may not transmit any harmful code (e.g., viruses, worms). You may not infringe the rights of others or interfere with the operation of the service.
            </p>

            <h2>8. Disclaimer of Warranties</h2>
            <p>
              WrenchLoop is provided "as is" and "as available," without warranty of any kind, express or implied. We disclaim all warranties, including implied warranties of merchantability, fitness for a particular purpose, and non-infringement.
            </p>

            <h2>9. Limitation of Liability</h2>
            <p>
              To the fullest extent permitted by law, WrenchLoop and its affiliates, officers, and employees shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of the service.
            </p>

            <h2>10. Changes to Terms</h2>
            <p>
              We may modify these Terms of Use at any time by posting the updated version on this page. Your continued use of WrenchLoop after such changes constitutes acceptance of the new terms.
            </p>

            <h2>11. Contact Information</h2>
            <p>
              If you have any questions about these Terms, please contact us at <a href="mailto:support@wrenchloop.com">support@wrenchloop.com</a>.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
