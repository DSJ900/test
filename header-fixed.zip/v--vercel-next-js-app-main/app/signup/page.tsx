import { redirect } from "next/navigation"
import { getSession } from "@/lib/supabase-server"
import { SignUpForm } from "./signup-form"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default async function SignUpPage() {
  const session = await getSession()

  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center py-12">
        <div className="mx-auto max-w-md w-full px-4 md:px-0">
          <div className="space-y-6">
            <div className="space-y-2 text-center">
              <h1 className="text-3xl font-bold">Sign Up</h1>
              <p className="text-gray-500">Create an account to start tracking your vehicles</p>
            </div>
            <SignUpForm />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
