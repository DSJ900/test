import { redirect } from "next/navigation"
import { getSession } from "@/lib/supabase-server"
import { LoginForm } from "./login-form"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default async function LoginPage() {
  const session = await getSession()

  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center py-12">
        <div className="mx-auto max-w-md w-full px-4 md:px-0">
          <div className="space-y-6">
            <div className="space-y-2 text-center">
              <h1 className="text-3xl font-bold">Sign In</h1>
              <p className="text-gray-500">Enter your email and password to sign in to your account</p>
            </div>
            <LoginForm />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
