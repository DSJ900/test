"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { formatCurrency, formatDate } from "@/lib/utils"
import { Bookmark, BookmarkX, Eye } from "lucide-react"
import Link from "next/link"

type BookmarkedRepair = {
  id: string
  created_at: string
  repair_id: string
  repair_logs: {
    id: string
    make: string
    model: string
    year: number
    issue_description: string
    cause: string
    total_cost: number | null
    created_at: string
    thumbs_up: number
    thumbs_down: number
  }
}

export function BookmarksContent() {
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [bookmarks, setBookmarks] = useState<BookmarkedRepair[]>([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    checkUser()
  }, [])

  async function checkUser() {
    const { data } = await supabase.auth.getUser()
    if (data.user) {
      setUser(data.user)
      fetchBookmarks(data.user.id)
    } else {
      router.push("/login")
    }
  }

  async function fetchBookmarks(userId: string) {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("bookmarks")
        .select(`
          *,
          repair_logs!inner(
            id,
            make,
            model,
            year,
            issue_description,
            cause,
            total_cost,
            created_at,
            thumbs_up,
            thumbs_down
          )
        `)
        .eq("user_id", userId)
        .order("created_at", { ascending: false })

      if (error) throw error

      setBookmarks(data || [])
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to fetch bookmarks.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  async function removeBookmark(bookmarkId: string) {
    try {
      const { error } = await supabase.from("bookmarks").delete().eq("id", bookmarkId)

      if (error) throw error

      setBookmarks(bookmarks.filter((b) => b.id !== bookmarkId))
      toast({
        title: "Success",
        description: "Bookmark removed successfully.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to remove bookmark.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Bookmarks</h1>
          <p className="text-gray-500">Your saved repair guides</p>
        </div>
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="bg-gray-100 h-20" />
              <CardContent className="py-4">
                <div className="h-4 bg-gray-100 rounded mb-2" />
                <div className="h-4 bg-gray-100 rounded w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Bookmarks</h1>
          <p className="text-gray-500">Your saved repair guides ({bookmarks.length})</p>
        </div>
      </div>

      {bookmarks.length > 0 ? (
        <div className="space-y-4">
          {bookmarks.map((bookmark) => (
            <Card key={bookmark.id}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{bookmark.repair_logs.issue_description}</CardTitle>
                    <CardDescription>
                      {bookmark.repair_logs.year} {bookmark.repair_logs.make} {bookmark.repair_logs.model}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">Bookmarked {formatDate(bookmark.created_at)}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="text-sm space-y-1">
                  <p>
                    <span className="font-medium">Cause:</span> {bookmark.repair_logs.cause}
                  </p>
                  {bookmark.repair_logs.total_cost !== null && (
                    <p>
                      <span className="font-medium">Cost:</span> {formatCurrency(bookmark.repair_logs.total_cost)}
                    </p>
                  )}
                  <p>
                    <span className="font-medium">Repair Date:</span> {formatDate(bookmark.repair_logs.created_at)}
                  </p>
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span>👍 {bookmark.repair_logs.thumbs_up}</span>
                    <span>👎 {bookmark.repair_logs.thumbs_down}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <div className="flex justify-between w-full">
                  <Link href={`/repairs/${bookmark.repair_logs.id}`}>
                    <Button variant="outline" size="sm">
                      <Eye className="mr-2 h-4 w-4" /> View Repair
                    </Button>
                  </Link>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeBookmark(bookmark.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <BookmarkX className="mr-2 h-4 w-4" /> Remove
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Bookmark className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium mb-2">No Bookmarks Yet</h3>
            <p className="text-gray-500 text-center mb-4">
              Start bookmarking repair guides to save them for later reference.
            </p>
            <Link href="/repairs">
              <Button>Browse Repairs</Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
