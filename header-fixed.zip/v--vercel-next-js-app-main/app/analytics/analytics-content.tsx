"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { formatCurrency } from "@/lib/utils"
import { BarChart, Car, DollarSign, Wrench, Clock, TrendingUp, AlertTriangle } from "lucide-react"

type Asset = {
  id: string
  name: string
  make: string
  model: string
  year: number
  created_at: string
}

type Analytics = {
  totalRepairCost: number
  totalMaintenanceCost: number
  combinedLifetimeCost: number
  repairCount: number
  maintenanceCount: number
  avgRepairCost: number
  avgMaintenanceCost: number
  mostCommonIssues: Array<{ issue: string; count: number }>
  mostReplacedParts: Array<{ part: string; count: number }>
  estimatedMonthlyCost: number
  daysSinceCreated: number
  assetCount?: number
}

type AnalyticsContentProps = {
  userId: string
  preselectedAssetId?: string
}

export function AnalyticsContent({ userId, preselectedAssetId }: AnalyticsContentProps) {
  const { supabase } = useSupabase()
  const { toast } = useToast()

  const [assets, setAssets] = useState<Asset[]>([])
  const [selectedAssetId, setSelectedAssetId] = useState<string>(preselectedAssetId || "")
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null)
  const [analytics, setAnalytics] = useState<Analytics | null>(null)
  const [loading, setLoading] = useState(true)
  const [timeFilter, setTimeFilter] = useState<"30days" | "year" | "ytd" | "all">("all")

  useEffect(() => {
    fetchAssets()
  }, [])

  useEffect(() => {
    if (selectedAssetId === "all") {
      setSelectedAsset(null)
      fetchAllAssetsAnalytics()
    } else if (selectedAssetId) {
      const asset = assets.find((a) => a.id === selectedAssetId) || null
      setSelectedAsset(asset)
      if (asset) fetchAnalytics(selectedAssetId)
    } else {
      setSelectedAsset(null)
      setAnalytics(null)
    }
  }, [selectedAssetId, assets, timeFilter])

  async function fetchAssets() {
    setLoading(true)
    try {
      const { data, error } = await supabase.from("assets").select("*").order("name")
      if (error) throw error
      setAssets(data || [])
      if (!preselectedAssetId && data && data.length > 0) {
        setSelectedAssetId(data[0].id)
      }
    } catch (err: any) {
      toast({ title: "Error", description: err.message || "Failed to fetch assets.", variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }

  async function fetchAllAssetsAnalytics() {
    setLoading(true)
    try {
      // build date filter
      let fromDate: string | null = null
      const now = new Date()
      if (timeFilter === "30days") {
        fromDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString()
      } else if (timeFilter === "year") {
        fromDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000).toISOString()
      } else if (timeFilter === "ytd") {
        fromDate = new Date(now.getFullYear(), 0, 1).toISOString()
      }

      const assetIds = assets.map((a) => a.id)

      // 1) Fetch all repair logs
      let rQ = supabase.from("repair_logs").select("*").in("asset_id", assetIds)
      if (fromDate) rQ = rQ.gte("created_at", fromDate)
      const { data: repairLogs, error: rErr } = await rQ
      if (rErr) throw rErr

      // 2) Fetch repair parts
      const repairIds = repairLogs?.map((l) => l.id) || []
      const { data: repairParts, error: rpErr } = await supabase
        .from("repair_parts")
        .select("*")
        .in("repair_log_id", repairIds)
      if (rpErr) throw rpErr

      // attach parts to each log
      const repairWithParts = (repairLogs || []).map((log) => ({
        ...log,
        parts: repairParts.filter((p) => p.repair_log_id === log.id),
      }))

      // 3) Fetch all maintenance logs
      let mQ = supabase.from("maintenance_logs").select("*").in("asset_id", assetIds)
      if (fromDate) mQ = mQ.gte("created_at", fromDate)
      const { data: maintenanceLogs, error: mErr } = await mQ
      if (mErr) throw mErr

      // 4) Fetch maintenance parts
      const maintenanceIds = maintenanceLogs?.map((l) => l.id) || []
      const { data: maintenanceParts, error: mpErr } = await supabase
        .from("maintenance_parts")
        .select("*")
        .in("maintenance_log_id", maintenanceIds)
      if (mpErr) throw mpErr

      // attach parts
      const maintenanceWithParts = (maintenanceLogs || []).map((log) => ({
        ...log,
        parts: maintenanceParts.filter((p) => p.maintenance_log_id === log.id),
      }))

      // compute costs
      const totalRepairCost = repairWithParts.reduce((sum, l) => sum + (l.total_cost || 0), 0)
      const totalMaintenanceCost = maintenanceWithParts.reduce((sum, l) => sum + (l.total_cost || 0), 0)
      const combinedLifetimeCost = totalRepairCost + totalMaintenanceCost
      const repairCount = repairWithParts.length
      const maintenanceCount = maintenanceWithParts.length
      const avgRepairCost = repairCount ? totalRepairCost / repairCount : 0
      const avgMaintenanceCost = maintenanceCount ? totalMaintenanceCost / maintenanceCount : 0

      // common issues
      const issueFreq: Record<string, number> = {}
      repairWithParts.forEach((l) => {
        const key = l.issue_description.toLowerCase()
        issueFreq[key] = (issueFreq[key] || 0) + 1
      })
      const mostCommonIssues = Object.entries(issueFreq)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([issue, count]) => ({ issue, count }))

      // most replaced parts
      const partFreq: Record<string, number> = {}
      ;[...repairWithParts, ...maintenanceWithParts]
        .flatMap((l) => l.parts)
        .forEach((p) => {
          const name = p.name.toLowerCase()
          partFreq[name] = (partFreq[name] || 0) + 1
        })
      const mostReplacedParts = Object.entries(partFreq)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([part, count]) => ({ part, count }))

      // Calculate average days since creation across all assets
      const totalDays = assets.reduce((sum, asset) => {
        const daysSinceCreated = Math.floor(
          (now.getTime() - new Date(asset.created_at).getTime()) / (1000 * 60 * 60 * 24),
        )
        return sum + daysSinceCreated
      }, 0)
      const avgDaysSinceCreated = assets.length ? totalDays / assets.length : 0
      const estimatedMonthlyCost = avgDaysSinceCreated ? (combinedLifetimeCost / avgDaysSinceCreated) * 30 : 0

      setAnalytics({
        totalRepairCost,
        totalMaintenanceCost,
        combinedLifetimeCost,
        repairCount,
        maintenanceCount,
        avgRepairCost,
        avgMaintenanceCost,
        mostCommonIssues,
        mostReplacedParts,
        estimatedMonthlyCost,
        daysSinceCreated: Math.round(avgDaysSinceCreated),
        assetCount: assets.length,
      })
    } catch (err: any) {
      toast({ title: "Error", description: err.message || "Failed to fetch analytics.", variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }

  async function fetchAnalytics(assetId: string) {
    setLoading(true)
    try {
      // build date filter
      let fromDate: string | null = null
      const now = new Date()
      if (timeFilter === "30days") {
        fromDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString()
      } else if (timeFilter === "year") {
        fromDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000).toISOString()
      } else if (timeFilter === "ytd") {
        fromDate = new Date(now.getFullYear(), 0, 1).toISOString()
      }

      // 1) Fetch repair logs
      let rQ = supabase.from("repair_logs").select("*").eq("asset_id", assetId)
      if (fromDate) rQ = rQ.gte("created_at", fromDate)
      const { data: repairLogs, error: rErr } = await rQ
      if (rErr) throw rErr

      // 2) Fetch repair parts
      const repairIds = repairLogs?.map((l) => l.id) || []
      const { data: repairParts, error: rpErr } = await supabase
        .from("repair_parts")
        .select("*")
        .in("repair_log_id", repairIds)
      if (rpErr) throw rpErr

      // attach parts to each log
      const repairWithParts = (repairLogs || []).map((log) => ({
        ...log,
        parts: repairParts.filter((p) => p.repair_log_id === log.id),
      }))

      // 3) Fetch maintenance logs
      let mQ = supabase.from("maintenance_logs").select("*").eq("asset_id", assetId)
      if (fromDate) mQ = mQ.gte("created_at", fromDate)
      const { data: maintenanceLogs, error: mErr } = await mQ
      if (mErr) throw mErr

      // 4) Fetch maintenance parts
      const maintenanceIds = maintenanceLogs?.map((l) => l.id) || []
      const { data: maintenanceParts, error: mpErr } = await supabase
        .from("maintenance_parts")
        .select("*")
        .in("maintenance_log_id", maintenanceIds)
      if (mpErr) throw mpErr

      // attach parts
      const maintenanceWithParts = (maintenanceLogs || []).map((log) => ({
        ...log,
        parts: maintenanceParts.filter((p) => p.maintenance_log_id === log.id),
      }))

      // compute costs
      const totalRepairCost = repairWithParts.reduce((sum, l) => sum + (l.total_cost || 0), 0)
      const totalMaintenanceCost = maintenanceWithParts.reduce((sum, l) => sum + (l.total_cost || 0), 0)
      const combinedLifetimeCost = totalRepairCost + totalMaintenanceCost
      const repairCount = repairWithParts.length
      const maintenanceCount = maintenanceWithParts.length
      const avgRepairCost = repairCount ? totalRepairCost / repairCount : 0
      const avgMaintenanceCost = maintenanceCount ? totalMaintenanceCost / maintenanceCount : 0

      // common issues
      const issueFreq: Record<string, number> = {}
      repairWithParts.forEach((l) => {
        const key = l.issue_description.toLowerCase()
        issueFreq[key] = (issueFreq[key] || 0) + 1
      })
      const mostCommonIssues = Object.entries(issueFreq)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([issue, count]) => ({ issue, count }))

      // most replaced parts
      const partFreq: Record<string, number> = {}
      ;[...repairWithParts, ...maintenanceWithParts]
        .flatMap((l) => l.parts)
        .forEach((p) => {
          const name = p.name.toLowerCase()
          partFreq[name] = (partFreq[name] || 0) + 1
        })
      const mostReplacedParts = Object.entries(partFreq)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([part, count]) => ({ part, count }))

      // days since creation
      const asset = assets.find((a) => a.id === assetId)
      const daysSinceCreated = asset
        ? Math.floor((now.getTime() - new Date(asset.created_at).getTime()) / (1000 * 60 * 60 * 24))
        : 0
      const estimatedMonthlyCost = daysSinceCreated ? (combinedLifetimeCost / daysSinceCreated) * 30 : 0

      setAnalytics({
        totalRepairCost,
        totalMaintenanceCost,
        combinedLifetimeCost,
        repairCount,
        maintenanceCount,
        avgRepairCost,
        avgMaintenanceCost,
        mostCommonIssues,
        mostReplacedParts,
        estimatedMonthlyCost,
        daysSinceCreated,
      })
    } catch (err: any) {
      toast({ title: "Error", description: err.message || "Failed to fetch analytics.", variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }

  if (assets.length === 0 && !loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Analytics</h1>
        <p className="text-gray-500">Track your vehicle performance and costs</p>
        <Card>
          <CardContent className="py-12 text-center">
            <Car className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium">No Assets Found</h3>
            <p className="text-gray-500">Add vehicles before viewing analytics.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <h1 className="text-3xl font-bold">Analytics</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Select Vehicle</label>
          <Select value={selectedAssetId} onValueChange={setSelectedAssetId}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a vehicle" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Assets Combined</SelectItem>
              {assets.map((a) => (
                <SelectItem key={a.id} value={a.id}>
                  {a.name} ({a.year} {a.make} {a.model})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Time Period</label>
          <Select value={timeFilter} onValueChange={(v) => setTimeFilter(v as any)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="30days">Past 30 Days</SelectItem>
              <SelectItem value="year">Past Year</SelectItem>
              <SelectItem value="ytd">Year to Date</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {selectedAssetId === "all" && analytics && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="h-5 w-5" /> All Assets Combined
              </CardTitle>
              <CardDescription>Analytics across {analytics.assetCount} vehicles</CardDescription>
            </CardHeader>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Total Repair Cost</CardTitle>
                <Wrench className="h-4 w-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(analytics.totalRepairCost)}</div>
                <p className="text-xs text-gray-500">{analytics.repairCount} repairs</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Total Maintenance Cost</CardTitle>
                <Clock className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(analytics.totalMaintenanceCost)}</div>
                <p className="text-xs text-gray-500">{analytics.maintenanceCount} services</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Combined Fleet Cost</CardTitle>
                <DollarSign className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(analytics.combinedLifetimeCost)}</div>
                <p className="text-xs text-gray-500">Total fleet investment</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Est. Monthly Cost</CardTitle>
                <TrendingUp className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(analytics.estimatedMonthlyCost)}</div>
                <p className="text-xs text-gray-500">Avg. {analytics.daysSinceCreated} days per asset</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Average Costs</CardTitle>
                <BarChart className="h-4 w-4 text-gray-600" />
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span>Avg. Repair Cost:</span>
                  <span className="font-medium">{formatCurrency(analytics.avgRepairCost)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Avg. Maintenance Cost:</span>
                  <span className="font-medium">{formatCurrency(analytics.avgMaintenanceCost)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Most Common Issues</CardTitle>
                <AlertTriangle className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                {analytics.mostCommonIssues.length > 0 ? (
                  <div className="space-y-2">
                    {analytics.mostCommonIssues.map((issue, idx) => (
                      <div key={idx} className="flex justify-between text-sm">
                        <span className="capitalize truncate">{issue.issue}</span>
                        <span className="font-medium">{issue.count}×</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">No repair data yet</p>
                )}
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Most Replaced Parts</CardTitle>
                <CardDescription>Parts replaced most frequently across all assets</CardDescription>
              </CardHeader>
              <CardContent>
                {analytics.mostReplacedParts.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {analytics.mostReplacedParts.map((p, idx) => (
                      <div key={idx} className="flex justify-between text-sm">
                        <span className="capitalize truncate">{p.part}</span>
                        <span className="font-medium">{p.count}×</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">No parts data available</p>
                )}
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {selectedAsset && analytics && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="h-5 w-5" /> {selectedAsset.name}
              </CardTitle>
              <CardDescription>
                {selectedAsset.year} {selectedAsset.make} {selectedAsset.model}
              </CardDescription>
            </CardHeader>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Total Repair Cost</CardTitle>
                <Wrench className="h-4 w-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(analytics.totalRepairCost)}</div>
                <p className="text-xs text-gray-500">{analytics.repairCount} repairs</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Total Maintenance Cost</CardTitle>
                <Clock className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(analytics.totalMaintenanceCost)}</div>
                <p className="text-xs text-gray-500">{analytics.maintenanceCount} services</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Combined Lifetime Cost</CardTitle>
                <DollarSign className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(analytics.combinedLifetimeCost)}</div>
                <p className="text-xs text-gray-500">Total investment</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Est. Monthly Cost</CardTitle>
                <TrendingUp className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(analytics.estimatedMonthlyCost)}</div>
                <p className="text-xs text-gray-500">Based on {analytics.daysSinceCreated} days</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Average Costs</CardTitle>
                <BarChart className="h-4 w-4 text-gray-600" />
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span>Avg. Repair Cost:</span>
                  <span className="font-medium">{formatCurrency(analytics.avgRepairCost)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Avg. Maintenance Cost:</span>
                  <span className="font-medium">{formatCurrency(analytics.avgMaintenanceCost)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex justify-between pb-2">
                <CardTitle className="text-sm font-medium">Most Common Issues</CardTitle>
                <AlertTriangle className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                {analytics.mostCommonIssues.length > 0 ? (
                  <div className="space-y-2">
                    {analytics.mostCommonIssues.map((issue, idx) => (
                      <div key={idx} className="flex justify-between text-sm">
                        <span className="capitalize truncate">{issue.issue}</span>
                        <span className="font-medium">{issue.count}×</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">No repair data yet</p>
                )}
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Most Replaced Parts</CardTitle>
                <CardDescription>Parts replaced most frequently</CardDescription>
              </CardHeader>
              <CardContent>
                {analytics.mostReplacedParts.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {analytics.mostReplacedParts.map((p, idx) => (
                      <div key={idx} className="flex justify-between text-sm">
                        <span className="capitalize truncate">{p.part}</span>
                        <span className="font-medium">{p.count}×</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">No parts data available</p>
                )}
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {!selectedAssetId && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <BarChart className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium mb-2">Select a Vehicle</h3>
            <p className="text-gray-500 text-center">Choose a vehicle from the dropdown above to view its analytics.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

