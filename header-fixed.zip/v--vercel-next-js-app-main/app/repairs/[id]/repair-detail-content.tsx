"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { formatCurrency, formatDate } from "@/lib/utils"
import { ThumbsUp, ThumbsDown, Bookmark, MessageSquare, Wrench, Calendar, Car } from "lucide-react"

type RepairDetailProps = {
  repair: any
}

export function RepairDetailContent({ repair }: RepairDetailProps) {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [user, setUser] = useState<any>(null)
  const [comment, setComment] = useState("")
  const [comments, setComments] = useState(repair.comments || [])
  const [userVote, setUserVote] = useState<string | null>(null)
  const [isBookmarked, setIsBookmarked] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    checkUser()
  }, [])

  async function checkUser() {
    try {
      const { data } = await supabase.auth.getUser()
      setUser(data.user)

      if (data.user) {
        // Check if user has voted
        const { data: vote } = await supabase
          .from("votes")
          .select("vote_type")
          .eq("user_id", data.user.id)
          .eq("repair_id", repair.id)
          .single()

        if (vote) {
          setUserVote(vote.vote_type)
        }

        // Check if bookmarked
        const { data: bookmark } = await supabase
          .from("bookmarks")
          .select("id")
          .eq("user_id", data.user.id)
          .eq("repair_id", repair.id)
          .single()

        setIsBookmarked(!!bookmark)
      }
    } catch (error) {
      console.error("Error checking user:", error)
    }
  }

  async function handleVote(voteType: "up" | "down") {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "You need to sign in to vote on repairs.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      if (userVote === voteType) {
        // Remove vote
        await supabase.from("votes").delete().eq("user_id", user.id).eq("repair_id", repair.id)
        setUserVote(null)
      } else {
        // Add or update vote
        await supabase.from("votes").upsert({
          user_id: user.id,
          repair_id: repair.id,
          vote_type: voteType,
        })
        setUserVote(voteType)
      }

      toast({
        title: "Success",
        description: "Vote updated successfully.",
      })
    } catch (error: any) {
      console.error("Vote error:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to vote.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  async function handleBookmark() {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "You need to sign in to bookmark repairs.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      if (isBookmarked) {
        await supabase.from("bookmarks").delete().eq("user_id", user.id).eq("repair_id", repair.id)
        setIsBookmarked(false)
        toast({ title: "Success", description: "Bookmark removed." })
      } else {
        await supabase.from("bookmarks").insert({
          user_id: user.id,
          repair_id: repair.id,
        })
        setIsBookmarked(true)
        toast({ title: "Success", description: "Repair bookmarked." })
      }
    } catch (error: any) {
      console.error("Bookmark error:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to bookmark.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  async function handleAddComment() {
    if (!user || !comment.trim()) return

    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("comments")
        .insert({
          user_id: user.id,
          repair_id: repair.id,
          content: comment.trim(),
        })
        .select("*, profiles(email)")
        .single()

      if (error) throw error

      setComments([...comments, data])
      setComment("")
      toast({ title: "Success", description: "Comment added." })
    } catch (error: any) {
      console.error("Comment error:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to add comment.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (!repair) {
    return (
      <div className="text-center py-8">
        <p>Repair not found or not available.</p>
      </div>
    )
  }

  const thumbsUp = repair.votes?.filter((vote: any) => vote.vote_type === "up").length || repair.thumbs_up || 0
  const thumbsDown = repair.votes?.filter((vote: any) => vote.vote_type === "down").length || repair.thumbs_down || 0

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">{repair.issue_description}</h1>
          <p className="text-gray-500">
            {repair.year} {repair.make} {repair.model}
            {repair.asset?.name && ` - ${repair.asset.name}`}
          </p>
        </div>
        <div className="flex gap-2">
          {user && (
            <>
              <Button
                variant={userVote === "up" ? "default" : "outline"}
                size="sm"
                onClick={() => handleVote("up")}
                disabled={loading}
              >
                <ThumbsUp className="h-4 w-4 mr-1" />
                {thumbsUp}
              </Button>
              <Button
                variant={userVote === "down" ? "destructive" : "outline"}
                size="sm"
                onClick={() => handleVote("down")}
                disabled={loading}
              >
                <ThumbsDown className="h-4 w-4 mr-1" />
                {thumbsDown}
              </Button>
              <Button
                variant={isBookmarked ? "default" : "outline"}
                size="sm"
                onClick={handleBookmark}
                disabled={loading}
              >
                <Bookmark className="h-4 w-4" />
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wrench className="h-5 w-5" />
                Repair Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium">Issue Description</h4>
                <p className="text-gray-600">{repair.issue_description}</p>
              </div>
              <div>
                <h4 className="font-medium">Root Cause</h4>
                <p className="text-gray-600">{repair.cause}</p>
              </div>
              {repair.repair_notes && (
                <div>
                  <h4 className="font-medium">Repair Notes</h4>
                  <p className="text-gray-600">{repair.repair_notes}</p>
                </div>
              )}
              {repair.tools_used && (
                <div>
                  <h4 className="font-medium">Tools Used</h4>
                  <p className="text-gray-600">{repair.tools_used}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {repair.parts && repair.parts.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Parts Used</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {repair.parts.map((part: any) => (
                    <div key={part.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">{part.name}</p>
                        {part.part_number && <p className="text-sm text-gray-500">Part #: {part.part_number}</p>}
                      </div>
                      {part.price && <Badge variant="secondary">{formatCurrency(part.price)}</Badge>}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {repair.photos && repair.photos.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Photos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {repair.photos.map((photo: any) => (
                    <img
                      key={photo.id}
                      src={photo.url || "/placeholder.svg?height=128&width=128"}
                      alt="Repair photo"
                      className="w-full h-32 object-cover rounded-lg"
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Comments
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {user && (
                <div className="space-y-2">
                  <Textarea
                    placeholder="Add a comment..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                  />
                  <Button onClick={handleAddComment} disabled={!comment.trim() || loading}>
                    Add Comment
                  </Button>
                </div>
              )}
              <div className="space-y-4">
                {comments.map((comment: any) => (
                  <div key={comment.id} className="border-l-2 border-gray-200 pl-4">
                    <div className="flex justify-between items-start">
                      <p className="text-sm font-medium">{comment.profiles?.email || "Anonymous"}</p>
                      <p className="text-xs text-gray-500">{formatDate(comment.created_at)}</p>
                    </div>
                    <p className="text-gray-600 mt-1">{comment.content}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="h-5 w-5" />
                Vehicle Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Make:</span>
                <span className="font-medium">{repair.make}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Model:</span>
                <span className="font-medium">{repair.model}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Year:</span>
                <span className="font-medium">{repair.year}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Engine:</span>
                <span className="font-medium">{repair.engine}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Transmission:</span>
                <span className="font-medium">{repair.transmission}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">Repair completed on {formatDate(repair.created_at)}</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
