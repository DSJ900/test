import { notFound } from "next/navigation"
import { createServerSupabaseClient } from "@/lib/supabase-server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { RepairDetailContent } from "./repair-detail-content"
import { ReportButton } from "@/components/report-button"

export default async function RepairDetailPage({
  params,
}: {
  params: { id: string }
}) {
  const supabase = createServerSupabaseClient()

  try {
    // Get logged-in user (optional for showing ReportButton)
    const {
      data: { user },
    } = await supabase.auth.getUser()

    // Get the repair log
    const { data: repair, error: repairError } = await supabase
      .from("repair_logs")
      .select("*")
      .eq("id", params.id)
      .eq("is_public", true)
      .eq("is_hidden", false)
      .single()

    if (repairError || !repair) {
      console.error("Repair not found:", repairError)
      notFound()
    }

    // Get related asset
    let asset = null
    if (repair.asset_id) {
      const { data: assetData } = await supabase
        .from("assets")
        .select("name")
        .eq("id", repair.asset_id)
        .single()
      asset = assetData
    }

    // Get parts, photos, comments, votes
    const { data: parts } = await supabase
      .from("parts")
      .select("*")
      .eq("log_id", repair.id)
      .eq("log_type", "repair")

    const { data: photos } = await supabase
      .from("photos")
      .select("*")
      .eq("log_id", repair.id)
      .eq("log_type", "repair")

    const { data: comments } = await supabase
      .from("comments")
      .select(`*, profiles!inner(email)`)
      .eq("repair_id", repair.id)
      .order("created_at", { ascending: true })

    const { data: votes } = await supabase
      .from("votes")
      .select("vote_type")
      .eq("repair_id", repair.id)

    const repairWithRelations = {
      ...repair,
      asset,
      parts: parts || [],
      photos: photos || [],
      comments: comments || [],
      votes: votes || [],
    }

    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8 space-y-6">
          <RepairDetailContent repair={repairWithRelations} />
          {user && (
            <div className="pt-8 border-t">
              <ReportButton postId={repair.id} />
            </div>
          )}
        </main>
        <Footer />
      </div>
    )
  } catch (error) {
    console.error("Error fetching repair:", error)
    notFound()
  }
}