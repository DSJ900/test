"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { formatCurrency, formatDate, normalizeSearchTerm } from "@/lib/utils"
import { Search, ThumbsUp, ThumbsDown, Bookmark, FileText, Printer } from "lucide-react"
import Link from "next/link"

type RepairLog = {
  id: string
  created_at: string
  make: string
  model: string
  year: number
  engine: string
  transmission: string
  issue_description: string
  cause: string
  total_cost: number | null
  thumbs_up: number
  thumbs_down: number
  asset?: {
    name: string
  }
}

type FilterOptions = {
  makes: string[]
  models: string[]
  years: number[]
  engines: string[]
  transmissions: string[]
}

export function RepairsContent({ initialSearch = "" }: {initialSearch?: string }) {
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [repairs, setRepairs] = useState<RepairLog[]>([])
  const [filteredRepairs, setFilteredRepairs] = useState<RepairLog[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState(initialSearch)
  const [filters, setFilters] = useState({
    make: "all",
    model: "all",
    year: "all",
    engine: "all",
    transmission: "all",
  })
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    makes: [],
    models: [],
    years: [],
    engines: [],
    transmissions: [],
  })
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    fetchRepairs()
    checkUser()
  }, [])

  useEffect(() => {
    applyFilters()
  }, [repairs, searchTerm, filters])

  async function checkUser() {
    const { data } = await supabase.auth.getUser()
    setUser(data.user)
  }

  async function fetchRepairs() {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("repair_logs")
        .select("*, asset:assets(name)")
        .eq("is_public", true)
        .eq("is_hidden", false)
        .order("created_at", { ascending: false })

      if (error) throw error

      setRepairs(data || [])
      generateFilterOptions(data || [])
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to fetch repairs.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  function generateFilterOptions(repairData: RepairLog[]) {
    const makes = [...new Set(repairData.map((r) => r.make))].sort()
    const models = [...new Set(repairData.map((r) => r.model))].sort()
    const years = [...new Set(repairData.map((r) => r.year))].sort((a, b) => b - a)
    const engines = [...new Set(repairData.map((r) => r.engine))].sort()
    const transmissions = [...new Set(repairData.map((r) => r.transmission))].sort()

    setFilterOptions({
      makes,
      models,
      years,
      engines,
      transmissions,
    })
  }

  function applyFilters() {
    let filtered = repairs

    // Apply search term
    if (searchTerm) {
      const searchLower = normalizeSearchTerm(searchTerm)
      filtered = filtered.filter(
        (repair) =>
          normalizeSearchTerm(repair.make).includes(searchLower) ||
          normalizeSearchTerm(repair.model).includes(searchLower) ||
          normalizeSearchTerm(repair.issue_description).includes(searchLower) ||
          normalizeSearchTerm(repair.cause).includes(searchLower) ||
          normalizeSearchTerm(repair.engine).includes(searchLower) ||
          normalizeSearchTerm(repair.transmission).includes(searchLower) ||
          (repair.asset?.name && normalizeSearchTerm(repair.asset.name).includes(searchLower)),
      )
    }

    // Apply filters
    if (filters.make && filters.make !== "all") {
      filtered = filtered.filter((repair) => normalizeSearchTerm(repair.make) === normalizeSearchTerm(filters.make))
    }
    if (filters.model && filters.model !== "all") {
      filtered = filtered.filter((repair) => normalizeSearchTerm(repair.model) === normalizeSearchTerm(filters.model))
    }
    if (filters.year && filters.year !== "all") {
      filtered = filtered.filter((repair) => repair.year.toString() === filters.year)
    }
    if (filters.engine && filters.engine !== "all") {
      filtered = filtered.filter((repair) => normalizeSearchTerm(repair.engine) === normalizeSearchTerm(filters.engine))
    }
    if (filters.transmission && filters.transmission !== "all") {
      filtered = filtered.filter(
        (repair) => normalizeSearchTerm(repair.transmission) === normalizeSearchTerm(filters.transmission),
      )
    }

    setFilteredRepairs(filtered)
  }

  function handleFilterChange(key: string, value: string) {
    setFilters((prev) => {
      const newFilters = { ...prev, [key]: value }

      // Reset dependent filters when parent changes
      if (key === "make") {
        newFilters.model = ""
        newFilters.year = ""
        newFilters.engine = ""
        newFilters.transmission = ""
      }

      return newFilters
    })
  }

  function clearFilters() {
    setFilters({
      make: "all",
      model: "all",
      year: "all",
      engine: "all",
      transmission: "all",
    })
    setSearchTerm("")
  }

  async function handleVote(repairId: string, voteType: "up" | "down") {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "You need to sign in to vote on repairs.",
        variant: "destructive",
      })
      return
    }

    try {
      // Check if user already voted
      const { data: existingVote } = await supabase
        .from("votes")
        .select("*")
        .eq("user_id", user.id)
        .eq("repair_id", repairId)
        .single()

      if (existingVote) {
        if (existingVote.vote_type === voteType) {
          // Remove vote if clicking same vote
          await supabase.from("votes").delete().eq("id", existingVote.id)
        } else {
          // Update vote type
          await supabase.from("votes").update({ vote_type: voteType }).eq("id", existingVote.id)
        }
      } else {
        // Create new vote
        await supabase.from("votes").insert([
          {
            user_id: user.id,
            repair_id: repairId,
            vote_type: voteType,
          },
        ])
      }

      // Refresh repairs to get updated vote counts
      fetchRepairs()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to vote.",
        variant: "destructive",
      })
    }
  }

  async function handleBookmark(repairId: string) {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "You need to sign in to bookmark repairs.",
        variant: "destructive",
      })
      return
    }

    try {
      // Check if already bookmarked
      const { data: existingBookmark } = await supabase
        .from("bookmarks")
        .select("*")
        .eq("user_id", user.id)
        .eq("repair_id", repairId)
        .single()

      if (existingBookmark) {
        // Remove bookmark
        await supabase.from("bookmarks").delete().eq("id", existingBookmark.id)

        toast({
          title: "Success",
          description: "Bookmark removed.",
        })
      } else {
        // Add bookmark
        await supabase.from("bookmarks").insert([
          {
            user_id: user.id,
            repair_id: repairId,
          },
        ])

        toast({
          title: "Success",
          description: "Repair bookmarked.",
        })
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to bookmark.",
        variant: "destructive",
      })
    }
  }

  // Get available options based on current filters
  const getAvailableModels = () => {
    if (!filters.make) return filterOptions.models
    return [
      ...new Set(
        repairs.filter((r) => normalizeSearchTerm(r.make) === normalizeSearchTerm(filters.make)).map((r) => r.model),
      ),
    ].sort()
  }

  const getAvailableYears = () => {
    let filtered = repairs
    if (filters.make) {
      filtered = filtered.filter((r) => normalizeSearchTerm(r.make) === normalizeSearchTerm(filters.make))
    }
    if (filters.model) {
      filtered = filtered.filter((r) => normalizeSearchTerm(r.model) === normalizeSearchTerm(filters.model))
    }
    return [...new Set(filtered.map((r) => r.year))].sort((a, b) => b - a)
  }

  const getAvailableEngines = () => {
    let filtered = repairs
    if (filters.make) {
      filtered = filtered.filter((r) => normalizeSearchTerm(r.make) === normalizeSearchTerm(filters.make))
    }
    if (filters.model) {
      filtered = filtered.filter((r) => normalizeSearchTerm(r.model) === normalizeSearchTerm(filters.model))
    }
    if (filters.year) {
      filtered = filtered.filter((r) => r.year.toString() === filters.year)
    }
    return [...new Set(filtered.map((r) => r.engine))].sort()
  }

  const getAvailableTransmissions = () => {
    let filtered = repairs
    if (filters.make) {
      filtered = filtered.filter((r) => normalizeSearchTerm(r.make) === normalizeSearchTerm(filters.make))
    }
    if (filters.model) {
      filtered = filtered.filter((r) => normalizeSearchTerm(r.model) === normalizeSearchTerm(filters.model))
    }
    if (filters.year) {
      filtered = filtered.filter((r) => r.year.toString() === filters.year)
    }
    if (filters.engine) {
      filtered = filtered.filter((r) => normalizeSearchTerm(r.engine) === normalizeSearchTerm(filters.engine))
    }
    return [...new Set(filtered.map((r) => r.transmission))].sort()
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Public Repair Library</h1>
          <p className="text-gray-500">Browse and learn from community repair experiences</p>
        </div>
        {user && (
          <Link href="/logs/new?type=repair">
            <Button>Share Your Repair</Button>
          </Link>
        )}
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Search & Filter</CardTitle>
          <CardDescription>Find specific repairs by vehicle details or issue description</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
            <Input
              placeholder="Search repairs..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Select value={filters.make} onValueChange={(value) => handleFilterChange("make", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Make" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Makes</SelectItem>
                {filterOptions.makes.map((make) => (
                  <SelectItem key={make} value={make}>
                    {make}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.model} onValueChange={(value) => handleFilterChange("model", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Model" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Models</SelectItem>
                {getAvailableModels().map((model) => (
                  <SelectItem key={model} value={model}>
                    {model}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.year} onValueChange={(value) => handleFilterChange("year", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Years</SelectItem>
                {getAvailableYears().map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.engine} onValueChange={(value) => handleFilterChange("engine", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Engine" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Engines</SelectItem>
                {getAvailableEngines().map((engine) => (
                  <SelectItem key={engine} value={engine}>
                    {engine}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.transmission} onValueChange={(value) => handleFilterChange("transmission", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Transmission" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Transmissions</SelectItem>
                {getAvailableTransmissions().map((transmission) => (
                  <SelectItem key={transmission} value={transmission}>
                    {transmission}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-500">
              Showing {filteredRepairs.length} of {repairs.length} repairs
            </p>
            <Button variant="outline" size="sm" onClick={clearFilters}>
              Clear Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {loading ? (
        <div className="space-y-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="bg-gray-100 h-20" />
              <CardContent className="py-4">
                <div className="h-4 bg-gray-100 rounded mb-2" />
                <div className="h-4 bg-gray-100 rounded w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredRepairs.length > 0 ? (
        <div className="space-y-4">
          {filteredRepairs.map((repair) => (
            <Card key={repair.id}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{repair.issue_description}</CardTitle>
                    <CardDescription>
                      {repair.year} {repair.make} {repair.model}
                      {repair.asset?.name && ` - ${repair.asset.name}`}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleVote(repair.id, "up")}
                        className="text-green-600 hover:text-green-700"
                      >
                        <ThumbsUp className="h-4 w-4" />
                        <span className="ml-1">{repair.thumbs_up}</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleVote(repair.id, "down")}
                        className="text-red-600 hover:text-red-700"
                      >
                        <ThumbsDown className="h-4 w-4" />
                        <span className="ml-1">{repair.thumbs_down}</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="text-sm space-y-1">
                  <p>
                    <span className="font-medium">Cause:</span> {repair.cause}
                  </p>
                  <p>
                    <span className="font-medium">Engine:</span> {repair.engine}
                  </p>
                  <p>
                    <span className="font-medium">Transmission:</span> {repair.transmission}
                  </p>
                  {repair.total_cost !== null && (
                    <p>
                      <span className="font-medium">Cost:</span> {formatCurrency(repair.total_cost)}
                    </p>
                  )}
                  <p>
                    <span className="font-medium">Date:</span> {formatDate(repair.created_at)}
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <div className="flex justify-between w-full">
                  <div className="flex gap-2">
                    <Link href={`/repairs/${repair.id}`}>
                      <Button variant="outline" size="sm">
                        <FileText className="mr-2 h-4 w-4" /> View Details
                      </Button>
                    </Link>
                    <Button variant="ghost" size="sm" onClick={() => window.print()}>
                      <Printer className="mr-2 h-4 w-4" /> Print
                    </Button>
                  </div>
                  {user && (
                    <Button variant="ghost" size="sm" onClick={() => handleBookmark(repair.id)}>
                      <Bookmark className="mr-2 h-4 w-4" /> Bookmark
                    </Button>
                  )}
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Search className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium mb-2">No Repairs Found</h3>
            <p className="text-gray-500 text-center mb-4">
              {searchTerm || Object.values(filters).some((f) => f)
                ? "No repairs match your search criteria. Try adjusting your filters."
                : "No public repairs available yet."}
            </p>
            {user && (
              <Link href="/logs/new?type=repair">
                <Button>Share the First Repair</Button>
              </Link>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
