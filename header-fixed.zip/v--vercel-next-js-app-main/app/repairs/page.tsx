import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Suspense } from "react"
import { RepairsContentWrapper } from "@/components/repairs-content-wrapper"

export default function RepairsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 w-full max-w-screen-xl mx-auto px-4 py-8">
        <Suspense fallback={<div>Loading repairs...</div>}>
          <RepairsContentWrapper />
        </Suspense>
      </main>
      <Footer />
    </div>
  )
}
